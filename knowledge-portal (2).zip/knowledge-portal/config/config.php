<?php
declare(strict_types=1);

// ---- Environment ----
// Defaults to 'local' so a fresh clone works out of the box on XAMPP/WAMP/MAMP.
// Set the APP_ENV environment variable to 'production' when you deploy behind real HTTPS.
define('APP_ENV', getenv('APP_ENV') ?: 'local');
define('APP_URL', getenv('APP_URL') ?: 'https://knowledge.yourorg.com');

// ---- Security hardening ----
error_reporting(APP_ENV === 'production' ? 0 : E_ALL);
ini_set('display_errors', APP_ENV === 'production' ? '0' : '1');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../logs/php_error.log');

// ---- Secure session configuration (must run before session_start) ----
ini_set('session.cookie_httponly', '1');   // JS can't read the session cookie -> mitigates XSS token theft
// Only require HTTPS-only cookies in production. On local XAMPP/WAMP/MAMP
// (plain http://localhost) this must be off or the session cookie never gets set.
ini_set('session.cookie_secure', APP_ENV === 'production' ? '1' : '0');
ini_set('session.cookie_samesite', 'Strict'); // CSRF mitigation
ini_set('session.use_strict_mode', '1');
ini_set('session.gc_maxlifetime', '1800'); // 30 min idle timeout

session_name('kp_session');

// ---- App constants ----
define('EDIT_WINDOW_DAYS', 7);
define('MAX_UPLOAD_MB', 25);
define('ALLOWED_EXTENSIONS', ['pdf','doc','docx','xls','xlsx','ppt','pptx','jpg','jpeg','png','txt','zip']);
define('UPLOAD_DIR', __DIR__ . '/../public/assets/uploads/');

define('ROLE_SUPER_USER', 1);
define('ROLE_ADMIN', 2);
define('ROLE_EMPLOYEE', 3);

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/Auth.php';
require_once __DIR__ . '/../includes/Csrf.php';
require_once __DIR__ . '/../includes/ActivityLogger.php';
require_once __DIR__ . '/../includes/KnowledgeAccess.php';
require_once __DIR__ . '/../includes/FileUpload.php';
