<?php
/**
 * Database connection (PDO)
 * Always use prepared statements — never interpolate user input into SQL.
 */

declare(strict_types=1);

final class Database
{
    private static ?PDO $instance = null;

    public static function connect(): PDO
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        // Defaults match XAMPP/WAMP/MAMP's out-of-the-box MySQL (root, no password)
        // so this works immediately on local dev. Override via environment
        // variables (DB_USER, DB_PASS, etc.) for any real deployment —
        // never run production against the root account.
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $port = getenv('DB_PORT') ?: '3306';
        $db   = getenv('DB_NAME') ?: 'knowledge_portal';
        $user = getenv('DB_USER') ?: 'root';
        $pass = getenv('DB_PASS') ?: '';
        $charset = 'utf8mb4';

        $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements, prevents SQLi
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$charset}",
        ];

        try {
            self::$instance = new PDO($dsn, $user, $pass, $options);
        } catch (PDOException $e) {
            error_log('DB connection failed: ' . $e->getMessage());
            http_response_code(500);
            if (defined('APP_ENV') && APP_ENV !== 'production') {
                // Local dev only — never leak this in production.
                exit('Database connection failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
                    . '<br>Check config/database.php credentials and that MySQL is running.');
            }
            exit('A system error occurred. Please try again later.');
        }

        return self::$instance;
    }
}
