<?php
declare(strict_types=1);
/**
 * Run via cron, e.g. daily:
 *   0 8 * * * php /path/to/knowledge-portal/scripts/notify_expiring.php
 */
require_once __DIR__ . '/../config/config.php';

$pdo = Database::connect();

// Entries expiring in the next 24 hours that haven't already been notified today
$stmt = $pdo->query(
    "SELECT knowledge_id, employee_id, title, editable_until
     FROM knowledge
     WHERE status = 'Submitted' AND is_deleted = 0
       AND editable_until BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 24 HOUR)"
);
$expiringSoon = $stmt->fetchAll();

$insert = $pdo->prepare(
    'INSERT INTO notifications (employee_id, knowledge_id, type, message)
     VALUES (:employee_id, :knowledge_id, "expiring_soon", :message)'
);

foreach ($expiringSoon as $row) {
    // Avoid duplicate notifications for the same entry within 24h
    $exists = $pdo->prepare(
        "SELECT COUNT(*) FROM notifications
         WHERE knowledge_id = :kid AND type = 'expiring_soon' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
    );
    $exists->execute(['kid' => $row['knowledge_id']]);
    if ($exists->fetchColumn() > 0) {
        continue;
    }

    $insert->execute([
        'employee_id'  => $row['employee_id'],
        'knowledge_id' => $row['knowledge_id'],
        'message'      => "Your knowledge entry \"{$row['title']}\" can be edited for the next 24 hours.",
    ]);
}

echo count($expiringSoon) . " expiring-soon notification(s) processed.\n";

// Entries that just passed their window — one-time "expired" notice
$stmtExpired = $pdo->query(
    "SELECT knowledge_id, employee_id, title
     FROM knowledge
     WHERE status = 'Submitted' AND is_deleted = 0
       AND editable_until BETWEEN DATE_SUB(NOW(), INTERVAL 24 HOUR) AND NOW()"
);
$justExpired = $stmtExpired->fetchAll();

$insertExpired = $pdo->prepare(
    'INSERT INTO notifications (employee_id, knowledge_id, type, message)
     VALUES (:employee_id, :knowledge_id, "expired", :message)'
);

foreach ($justExpired as $row) {
    $exists = $pdo->prepare(
        "SELECT COUNT(*) FROM notifications WHERE knowledge_id = :kid AND type = 'expired'"
    );
    $exists->execute(['kid' => $row['knowledge_id']]);
    if ($exists->fetchColumn() > 0) {
        continue;
    }

    $insertExpired->execute([
        'employee_id'  => $row['employee_id'],
        'knowledge_id' => $row['knowledge_id'],
        'message'      => "The 7-day editing period for \"{$row['title']}\" has expired.",
    ]);
}

echo count($justExpired) . " expired notification(s) processed.\n";
