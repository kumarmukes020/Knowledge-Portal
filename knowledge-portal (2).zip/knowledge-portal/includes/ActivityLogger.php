<?php
declare(strict_types=1);

final class ActivityLogger
{
    public static function log(?int $employeeId, string $action, string $module, ?int $recordId = null, ?string $description = null): void
    {
        try {
            $pdo = Database::connect();
            $stmt = $pdo->prepare(
                'INSERT INTO activity_logs (employee_id, action, module, record_id, description, ip_address, user_agent)
                 VALUES (:employee_id, :action, :module, :record_id, :description, :ip, :ua)'
            );
            $stmt->execute([
                'employee_id' => $employeeId,
                'action'      => $action,
                'module'      => $module,
                'record_id'   => $recordId,
                'description' => $description,
                'ip'          => $_SERVER['REMOTE_ADDR'] ?? null,
                'ua'          => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            ]);
        } catch (Throwable $e) {
            // Logging must never break the app
            error_log('ActivityLogger failed: ' . $e->getMessage());
        }
    }
}
