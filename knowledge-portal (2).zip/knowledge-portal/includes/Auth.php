<?php
declare(strict_types=1);

/**
 * Handles authentication, session lifecycle, and role checks.
 */
final class Auth
{
    private const MAX_FAILED_ATTEMPTS = 5;
    private const LOCKOUT_MINUTES = 15;

    public static function start(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Regenerate session ID periodically to prevent fixation
        if (empty($_SESSION['created_at'])) {
            $_SESSION['created_at'] = time();
        } elseif (time() - $_SESSION['created_at'] > 900) {
            session_regenerate_id(true);
            $_SESSION['created_at'] = time();
        }

        // Idle timeout
        if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
            self::logout();
        }
        $_SESSION['last_activity'] = time();
    }

    /**
     * Attempt to log in. Returns true on success, false on failure.
     * Login is by username OR email — identifier is not user-interpolated into SQL.
     */
    public static function attemptLogin(string $identifier, string $password): array
    {
        $pdo = Database::connect();

        $stmt = $pdo->prepare(
            'SELECT e.employee_id, e.employee_name, e.username, e.password_hash,
                    e.status, e.role_id, e.failed_login_attempts, e.locked_until,
                    e.must_change_password, r.role_name
             FROM employees e
             JOIN roles r ON r.role_id = e.role_id
             WHERE e.username = :identifier_username OR e.email = :identifier_email
             LIMIT 1'
        );
        $stmt->execute(['identifier_username' => $identifier, 'identifier_email' => $identifier]);
        $user = $stmt->fetch();

        // Constant-shape response whether or not user exists, to avoid user enumeration timing leaks
        if (!$user) {
            password_verify($password, '$2y$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinva');
            return ['success' => false, 'message' => 'Invalid username or password.'];
        }

        if ($user['status'] !== 'Active') {
            return ['success' => false, 'message' => 'This account is inactive. Contact your administrator.'];
        }

        if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
            return ['success' => false, 'message' => 'Account temporarily locked due to failed login attempts. Try again later.'];
        }

        if (!password_verify($password, $user['password_hash'])) {
            self::registerFailedAttempt($pdo, (int)$user['employee_id'], (int)$user['failed_login_attempts']);
            return ['success' => false, 'message' => 'Invalid username or password.'];
        }

        // Success: reset failed attempts, rehash if needed, regenerate session ID
        $pdo->prepare('UPDATE employees SET failed_login_attempts = 0, locked_until = NULL, last_login_at = NOW() WHERE employee_id = :id')
            ->execute(['id' => $user['employee_id']]);

        if (password_needs_rehash($user['password_hash'], PASSWORD_ARGON2ID)) {
            $newHash = password_hash($password, PASSWORD_ARGON2ID);
            $pdo->prepare('UPDATE employees SET password_hash = :h WHERE employee_id = :id')
                ->execute(['h' => $newHash, 'id' => $user['employee_id']]);
        }

        session_regenerate_id(true);
        $_SESSION['employee_id']   = (int)$user['employee_id'];
        $_SESSION['employee_name'] = $user['employee_name'];
        $_SESSION['role_id']       = (int)$user['role_id'];
        $_SESSION['role_name']     = $user['role_name'];
        $_SESSION['must_change_password'] = (bool)$user['must_change_password'];
        $_SESSION['last_activity'] = time();
        $_SESSION['created_at']    = time();

        ActivityLogger::log((int)$user['employee_id'], 'LOGIN', 'Auth', null, 'Successful login');

        return ['success' => true, 'role_name' => $user['role_name']];
    }

    private static function registerFailedAttempt(PDO $pdo, int $employeeId, int $currentAttempts): void
    {
        $attempts = $currentAttempts + 1;
        $lockedUntil = null;

        if ($attempts >= self::MAX_FAILED_ATTEMPTS) {
            $lockedUntil = (new DateTime())->modify('+' . self::LOCKOUT_MINUTES . ' minutes')->format('Y-m-d H:i:s');
        }

        $pdo->prepare('UPDATE employees SET failed_login_attempts = :a, locked_until = :l WHERE employee_id = :id')
            ->execute(['a' => $attempts, 'l' => $lockedUntil, 'id' => $employeeId]);

        ActivityLogger::log($employeeId, 'LOGIN_FAILED', 'Auth', null, "Failed attempt #{$attempts}");
    }

    public static function logout(): void
    {
        if (!empty($_SESSION['employee_id'])) {
            ActivityLogger::log((int)$_SESSION['employee_id'], 'LOGOUT', 'Auth', null, 'User logged out');
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }

    public static function isLoggedIn(): bool
    {
        return !empty($_SESSION['employee_id']);
    }

    public static function requireLogin(): void
    {
        if (!self::isLoggedIn()) {
            header('Location: login.php');
            exit;
        }

        // Force a password change before allowing access to anything else.
        // change-password.php and logout.php are exempt or this would loop forever.
        $currentPage = basename($_SERVER['SCRIPT_NAME']);
        $exempt = ['change-password.php', 'logout.php'];
        if (!empty($_SESSION['must_change_password']) && !in_array($currentPage, $exempt, true)) {
            header('Location: change-password.php?forced=1');
            exit;
        }
    }

    public static function requireRole(int ...$allowedRoleIds): void
    {
        self::requireLogin();
        if (!in_array((int)$_SESSION['role_id'], $allowedRoleIds, true)) {
            http_response_code(403);
            exit('403 — You do not have permission to access this page.');
        }
    }

    public static function currentEmployeeId(): ?int
    {
        return $_SESSION['employee_id'] ?? null;
    }

    public static function currentRoleId(): ?int
    {
        return $_SESSION['role_id'] ?? null;
    }

    public static function isSuperUser(): bool
    {
        return self::currentRoleId() === ROLE_SUPER_USER;
    }
}
