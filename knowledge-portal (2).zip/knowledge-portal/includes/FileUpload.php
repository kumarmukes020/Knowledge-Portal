<?php
declare(strict_types=1);

final class FileUpload
{
    private const MIME_MAP = [
        'pdf'  => ['application/pdf'],
        'doc'  => ['application/msword'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        'xls'  => ['application/vnd.ms-excel'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        'ppt'  => ['application/vnd.ms-powerpoint'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation'],
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
        'txt'  => ['text/plain'],
        'zip'  => ['application/zip', 'application/x-zip-compressed'],
    ];

    /**
     * @param array $file One entry from $_FILES
     * @return array{stored_name:string,file_path:string,file_name:string,file_type:string,mime_type:string,file_size:int}
     * @throws RuntimeException on any validation failure
     */
    public static function handle(array $file): array
    {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw new RuntimeException('Invalid file upload.');
        }

        switch ($file['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                throw new RuntimeException('No file was uploaded.');
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                throw new RuntimeException('File exceeds the maximum allowed size.');
            default:
                throw new RuntimeException('File upload failed.');
        }

        $maxBytes = MAX_UPLOAD_MB * 1024 * 1024;
        if ($file['size'] > $maxBytes) {
            throw new RuntimeException('File exceeds the ' . MAX_UPLOAD_MB . 'MB limit.');
        }

        $originalName = basename($file['name']);
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        if (!in_array($ext, ALLOWED_EXTENSIONS, true)) {
            throw new RuntimeException("File type .{$ext} is not permitted.");
        }

        // Verify the ACTUAL file content, not just the extension — prevents
        // a renamed .php file being uploaded as "report.pdf".
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $detectedMime = $finfo->file($file['tmp_name']);

        $allowedMimes = self::MIME_MAP[$ext] ?? [];
        if (!in_array($detectedMime, $allowedMimes, true)) {
            throw new RuntimeException('File content does not match its extension. Upload rejected.');
        }

        if (!is_uploaded_file($file['tmp_name'])) {
            throw new RuntimeException('Possible upload tampering detected.');
        }

        if (!is_dir(UPLOAD_DIR) && !mkdir(UPLOAD_DIR, 0750, true) && !is_dir(UPLOAD_DIR)) {
            throw new RuntimeException('Upload directory unavailable.');
        }

        // Unique, non-guessable stored filename — never trust the original name for storage.
        $storedName = bin2hex(random_bytes(16)) . '.' . $ext;
        $destination = rtrim(UPLOAD_DIR, '/') . '/' . $storedName;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new RuntimeException('Failed to save uploaded file.');
        }
        chmod($destination, 0640);

        return [
            'stored_name' => $storedName,
            'file_path'   => 'assets/uploads/' . $storedName,
            'file_name'   => $originalName,
            'file_type'   => $ext,
            'mime_type'   => $detectedMime,
            'file_size'   => (int)$file['size'],
        ];
    }

    /**
     * Handle multiple files from a single <input multiple name="attachments[]">.
     * @return array<int, array> list of successfully processed file metadata
     */
    public static function handleMultiple(array $filesField): array
    {
        $results = [];
        $count = count($filesField['name']);

        for ($i = 0; $i < $count; $i++) {
            if ($filesField['error'][$i] === UPLOAD_ERR_NO_FILE) {
                continue; // empty extra slot, not an error
            }
            $single = [
                'name'     => $filesField['name'][$i],
                'type'     => $filesField['type'][$i],
                'tmp_name' => $filesField['tmp_name'][$i],
                'error'    => $filesField['error'][$i],
                'size'     => $filesField['size'][$i],
            ];
            $results[] = self::handle($single);
        }

        return $results;
    }
}
