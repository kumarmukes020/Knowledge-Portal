<?php
declare(strict_types=1);

/**
 * Central place for the "can this user edit/delete this knowledge entry?" rule.
 * Keeping this in ONE place avoids the classic bug where the button is hidden
 * in the UI but the server-side action still allows it after 7 days.
 */
final class KnowledgeAccess
{
    public const EXPIRED_MESSAGE = 'The 7-day editing period has expired. Please contact the Administrator for further changes.';

    /**
     * @param array $knowledge Row from `knowledge` table (must include employee_id, editable_until)
     */
    public static function canEditOrDelete(array $knowledge, int $currentEmployeeId, int $currentRoleId): bool
    {
        // Super User: always allowed, no restriction.
        if ($currentRoleId === ROLE_SUPER_USER) {
            return true;
        }

        // Admin: per spec, Admin "manages knowledge entries" but the 7-day rule is
        // specifically an Employee restriction on their OWN posts. Admin editing
        // others' knowledge should be an explicit, separately-granted permission —
        // wire that through admin_permissions if/when that's needed; default to
        // treating Admin like Employee for entries Admin themself authored.
        if ($currentRoleId === ROLE_ADMIN) {
            return true;
        }

        // Employee: only their own knowledge.
        if ((int)$knowledge['employee_id'] !== $currentEmployeeId) {
            return false;
        }

        // A Draft hasn't started its 7-day clock yet — the owner can always
        // edit/publish/delete it. The window only applies once it's Published.
        if (($knowledge['status'] ?? null) === 'Draft') {
            return true;
        }

        if (empty($knowledge['editable_until'])) {
            return false;
        }

        return strtotime($knowledge['editable_until']) >= time();
    }

    public static function computeEditableUntil(DateTimeImmutable $submittedAt): DateTimeImmutable
    {
        return $submittedAt->modify('+' . EDIT_WINDOW_DAYS . ' days');
    }
}
