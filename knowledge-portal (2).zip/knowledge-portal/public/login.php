<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();

if (Auth::isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $identifier = trim($_POST['identifier'] ?? '');
    $password   = (string)($_POST['password'] ?? '');

    if ($identifier === '' || $password === '') {
        $error = 'Please enter both username/email and password.';
    } else {
        $result = Auth::attemptLogin($identifier, $password);
        if ($result['success']) {
            header('Location: dashboard.php');
            exit;
        }
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Knowledge Portal</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<div class="kp-login-wrap">
    <div class="kp-login-side">
        <h1>Share what you know.<br>Find what you need.</h1>
        <p class="mt-3 mb-0" style="opacity:.85;max-width:420px;position:relative;z-index:1;">
            One secure place for procedures, guides, lessons learned and technical notes across the organization.
        </p>
        <ul>
            <li><i class="bi bi-search"></i> Fast full-text search across all published knowledge</li>
            <li><i class="bi bi-paperclip"></i> Attach documents, sheets, presentations and images</li>
            <li><i class="bi bi-shield-check"></i> Role-based access with a complete audit trail</li>
        </ul>
    </div>
    <div class="kp-login-form">
        <div class="kp-login-box">
            <span class="kp-brand-icon"><i class="bi bi-lightbulb-fill"></i></span>
            <h3 class="mb-1">Welcome back</h3>
            <p class="text-muted mb-4">Sign in with your employee account</p>

            <?php if ($error): ?>
                <div class="alert alert-danger py-2"><i class="bi bi-exclamation-circle me-1"></i><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if (!empty($_GET['password_changed'])): ?>
                <div class="alert alert-success py-2"><i class="bi bi-check-circle me-1"></i>Password updated. Please log in with your new password.</div>
            <?php endif; ?>

            <form method="post" autocomplete="off" novalidate>
                <?= Csrf::field() ?>
                <div class="mb-3">
                    <label class="form-label">Username or Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-person"></i></span>
                        <input type="text" name="identifier" class="form-control" required autofocus>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-lock"></i></span>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2">Sign In</button>
            </form>
            <div class="text-center mt-4">
                <a href="portal.php" class="text-decoration-none small"><i class="bi bi-arrow-left me-1"></i>Browse public knowledge without signing in</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
