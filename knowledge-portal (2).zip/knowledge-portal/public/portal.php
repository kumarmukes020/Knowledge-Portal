<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
// Publicly viewable — no login required. Only Published, non-deleted knowledge
// is ever selectable below, so drafts/submitted-but-unpublished stay private.

$pdo = Database::connect();

$search      = trim($_GET['q'] ?? '');
$categoryId  = (int)($_GET['category_id'] ?? 0);
$departmentId = (int)($_GET['department_id'] ?? 0);
$dateFrom    = $_GET['date_from'] ?? '';
$dateTo      = $_GET['date_to'] ?? '';
$page        = max(1, (int)($_GET['page'] ?? 1));
$perPage     = 12;
$offset      = ($page - 1) * $perPage;

$where = ["k.status = 'Published'", "k.is_deleted = 0"];
$params = [];

if ($search !== '') {
    $where[] = "MATCH(k.title, k.description) AGAINST (:search IN NATURAL LANGUAGE MODE)";
    $params['search'] = $search;
}
if ($categoryId > 0) {
    $where[] = "k.category_id = :category_id";
    $params['category_id'] = $categoryId;
}
if ($departmentId > 0) {
    $where[] = "k.department_id = :department_id";
    $params['department_id'] = $departmentId;
}
if ($dateFrom !== '') {
    $where[] = "k.submitted_date >= :date_from";
    $params['date_from'] = $dateFrom . ' 00:00:00';
}
if ($dateTo !== '') {
    $where[] = "k.submitted_date <= :date_to";
    $params['date_to'] = $dateTo . ' 23:59:59';
}

$whereSql = implode(' AND ', $where);

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge k WHERE {$whereSql}");
$countStmt->execute($params);
$totalResults = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalResults / $perPage));

$sql = "SELECT k.knowledge_id, k.title, k.description, k.submitted_date,
               c.category_name, d.department_name, e.employee_name,
               (SELECT COUNT(*) FROM knowledge_attachments a WHERE a.knowledge_id = k.knowledge_id) AS attachment_count
        FROM knowledge k
        JOIN categories c   ON c.category_id = k.category_id
        JOIN employees e    ON e.employee_id = k.employee_id
        LEFT JOIN departments d ON d.department_id = k.department_id
        WHERE {$whereSql}
        ORDER BY k.submitted_date DESC
        LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $key => $val) {
    $stmt->bindValue(':' . $key, $val);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll();

$categories = $pdo->query('SELECT category_id, category_name FROM categories WHERE is_active = 1 ORDER BY category_name')->fetchAll();
$departments = $pdo->query('SELECT department_id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name')->fetchAll();

function qs(array $overrides = []): string {
    $params = array_merge($_GET, $overrides);
    return htmlspecialchars(http_build_query($params), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Knowledge Portal</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <form method="get" class="kp-hero">
        <h2>Knowledge Portal</h2>
        <p>Search procedures, guides and lessons learned shared by your colleagues.</p>
        <div class="row g-2">
            <div class="col-lg-5">
                <input type="text" name="q" class="form-control" placeholder="Search title or description…"
                       value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="col-lg-2 col-md-6">
                <select name="category_id" class="form-select">
                    <option value="0">All Categories</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['category_id'] ?>" <?= $categoryId === (int)$c['category_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['category_name'], ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-6">
                <select name="department_id" class="form-select">
                    <option value="0">All Departments</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= (int)$d['department_id'] ?>" <?= $departmentId === (int)$d['department_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($d['department_name'], ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-3 d-flex gap-2">
                <button type="submit" class="btn btn-accent flex-grow-1"><i class="bi bi-search me-1"></i>Search</button>
                <a href="portal.php" class="btn btn-outline-light">Clear</a>
            </div>
        </div>
        <div class="row g-2 mt-1">
            <div class="col-md-3 col-6">
                <input type="date" name="date_from" class="form-control" title="From date" value="<?= htmlspecialchars($dateFrom, ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="col-md-3 col-6">
                <input type="date" name="date_to" class="form-control" title="To date" value="<?= htmlspecialchars($dateTo, ENT_QUOTES, 'UTF-8') ?>">
            </div>
        </div>
    </form>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="text-muted"><strong class="text-dark"><?= $totalResults ?></strong> result<?= $totalResults === 1 ? '' : 's' ?> found</div>
    </div>

    <div class="row g-4">
        <?php if (empty($items)): ?>
            <div class="col-12"><div class="card"><div class="kp-empty"><i class="bi bi-search"></i>No published knowledge matches your search.</div></div></div>
        <?php endif; ?>
        <?php foreach ($items as $item): ?>
            <div class="col-md-6 col-xl-4">
                <div class="card h-100 kp-know-card kp-hover">
                    <div class="card-body d-flex flex-column p-4">
                        <div class="mb-3"><span class="kp-cat-badge"><?= htmlspecialchars($item['category_name'], ENT_QUOTES, 'UTF-8') ?></span></div>
                        <h6 class="card-title"><?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?></h6>
                        <p class="card-text text-muted small flex-grow-1">
                            <?= htmlspecialchars(mb_strimwidth(strip_tags($item['description']), 0, 130, '…'), ENT_QUOTES, 'UTF-8') ?>
                        </p>
                        <div class="kp-meta mb-3">
                            <div><i class="bi bi-person-circle"></i><?= htmlspecialchars($item['employee_name'], ENT_QUOTES, 'UTF-8') ?>
                                <?php if ($item['department_name']): ?> &middot; <?= htmlspecialchars($item['department_name'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?></div>
                            <div class="mt-1"><i class="bi bi-calendar3"></i><?= htmlspecialchars(date('d M Y', strtotime($item['submitted_date'])), ENT_QUOTES, 'UTF-8') ?>
                                &nbsp;&middot;&nbsp;<i class="bi bi-paperclip"></i><?= (int)$item['attachment_count'] ?> file<?= (int)$item['attachment_count'] === 1 ? '' : 's' ?></div>
                        </div>
                        <a href="knowledge-view.php?id=<?= (int)$item['knowledge_id'] ?>" class="btn btn-primary btn-sm">View Knowledge <i class="bi bi-arrow-right ms-1"></i></a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
        <nav class="mt-4 d-flex justify-content-center">
            <ul class="pagination">
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= qs(['page' => $p]) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php endif; ?>
    <div class="kp-footer">Knowledge Sharing Portal &middot; NTPC Mining Ltd. HQ, Ranchi</div>
</div>
</body>
</html>
