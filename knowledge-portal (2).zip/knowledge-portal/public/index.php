<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();

header('Location: ' . (Auth::isLoggedIn() ? 'dashboard.php' : 'portal.php'));
exit;
