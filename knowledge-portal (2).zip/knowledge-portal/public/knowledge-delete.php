<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

Csrf::requireValid();

$pdo = Database::connect();
$knowledgeId = (int)($_POST['knowledge_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM knowledge WHERE knowledge_id = :id AND is_deleted = 0');
$stmt->execute(['id' => $knowledgeId]);
$knowledge = $stmt->fetch();

if (!$knowledge) {
    http_response_code(404);
    exit('Knowledge entry not found.');
}

if (!KnowledgeAccess::canEditOrDelete($knowledge, (int)Auth::currentEmployeeId(), (int)Auth::currentRoleId())) {
    http_response_code(403);
    exit(KnowledgeAccess::EXPIRED_MESSAGE);
}

// Soft delete — keeps the audit trail and file records intact.
$pdo->prepare("UPDATE knowledge SET is_deleted = 1, status = 'Deleted' WHERE knowledge_id = :id")
    ->execute(['id' => $knowledgeId]);

ActivityLogger::log(Auth::currentEmployeeId(), 'DELETE', 'Knowledge', $knowledgeId, "Deleted \"{$knowledge['title']}\"");

header('Location: my-knowledge.php?deleted=1');
exit;
