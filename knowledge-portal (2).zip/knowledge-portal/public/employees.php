<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireRole(ROLE_SUPER_USER, ROLE_ADMIN);

$pdo = Database::connect();
$search = trim($_GET['q'] ?? '');

$sql = "SELECT e.employee_id, e.employee_number, e.employee_name, e.email, e.username,
               e.status, r.role_name, d.department_name, l.location_name
        FROM employees e
        JOIN roles r ON r.role_id = e.role_id
        LEFT JOIN departments d ON d.department_id = e.department_id
        LEFT JOIN locations l ON l.location_id = e.location_id";
$params = [];
if ($search !== '') {
    $sql .= " WHERE e.employee_name LIKE :s1 OR e.employee_number LIKE :s2 OR e.email LIKE :s3";
    $like = "%{$search}%";
    $params['s1'] = $like;
    $params['s2'] = $like;
    $params['s3'] = $like;
}
$sql .= " ORDER BY e.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0 kp-page-title"><i class="bi bi-people"></i>Employee Management</h4>
        <a href="employee-add.php" class="btn btn-primary btn-sm">+ Add Employee</a>
    </div>

    <form method="get" class="mb-3">
        <input type="text" name="q" class="form-control" style="max-width:300px" placeholder="Search name, number, email…"
               value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>">
    </form>

    <div class="table-responsive">
        <table class="table table-hover bg-white">
            <thead>
                <tr>
                    <th>Emp No.</th><th>Name</th><th>Department</th><th>Location</th><th>Role</th><th>Status</th><th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($employees as $emp): ?>
                    <tr>
                        <td><?= htmlspecialchars($emp['employee_number'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($emp['employee_name'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($emp['department_name'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($emp['location_name'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                        <td><span class="badge bg-secondary"><?= htmlspecialchars($emp['role_name'], ENT_QUOTES, 'UTF-8') ?></span></td>
                        <td>
                            <span class="badge <?= $emp['status'] === 'Active' ? 'bg-success' : 'bg-danger' ?>">
                                <?= htmlspecialchars($emp['status'], ENT_QUOTES, 'UTF-8') ?>
                            </span>
                        </td>
                        <td class="text-end">
                            <a href="employee-edit.php?id=<?= (int)$emp['employee_id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                            <?php if (Auth::isSuperUser()): ?>
                                <form method="post" action="employee-toggle.php" class="d-inline">
                                    <?= Csrf::field() ?>
                                    <input type="hidden" name="employee_id" value="<?= (int)$emp['employee_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-<?= $emp['status'] === 'Active' ? 'danger' : 'success' ?>">
                                        <?= $emp['status'] === 'Active' ? 'Deactivate' : 'Activate' ?>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
