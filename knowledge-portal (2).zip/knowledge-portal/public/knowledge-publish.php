<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
Csrf::requireValid();

$pdo = Database::connect();
$knowledgeId = (int)($_POST['knowledge_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM knowledge WHERE knowledge_id = :id AND is_deleted = 0');
$stmt->execute(['id' => $knowledgeId]);
$knowledge = $stmt->fetch();

if (!$knowledge) {
    http_response_code(404);
    exit('Knowledge entry not found.');
}

if ($knowledge['status'] !== 'Draft') {
    http_response_code(400);
    exit('Only draft entries can be published.');
}

if (!KnowledgeAccess::canEditOrDelete($knowledge, (int)Auth::currentEmployeeId(), (int)Auth::currentRoleId())) {
    http_response_code(403);
    exit('You do not have permission to publish this entry.');
}

$now = new DateTimeImmutable();
$editableUntil = KnowledgeAccess::computeEditableUntil($now);

$pdo->prepare(
    "UPDATE knowledge SET status = 'Published', submitted_date = :submitted, editable_until = :editable WHERE knowledge_id = :id"
)->execute([
    'submitted' => $now->format('Y-m-d H:i:s'),
    'editable'  => $editableUntil->format('Y-m-d H:i:s'),
    'id'        => $knowledgeId,
]);

ActivityLogger::log(Auth::currentEmployeeId(), 'UPDATE', 'Knowledge', $knowledgeId, "Published \"{$knowledge['title']}\"");

header('Location: my-knowledge.php?published=1');
exit;
