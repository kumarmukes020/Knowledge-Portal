<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin();

$pdo = Database::connect();
$roleId = Auth::currentRoleId();
$roleName = $_SESSION['role_name'];
$employeeId = Auth::currentEmployeeId();

// Stats scoped by role — Employee only ever sees their own numbers
if ($roleId === ROLE_SUPER_USER || $roleId === ROLE_ADMIN) {
    $totalEmployees  = $pdo->query('SELECT COUNT(*) FROM employees')->fetchColumn();
    $activeEmployees = $pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'")->fetchColumn();
    $totalKnowledge  = $pdo->query("SELECT COUNT(*) FROM knowledge WHERE is_deleted = 0")->fetchColumn();
} else {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge WHERE employee_id = :id AND is_deleted = 0");
    $stmt->execute(['id' => $employeeId]);
    $myKnowledgeCount = $stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge WHERE employee_id = :id AND is_deleted = 0 AND editable_until >= NOW()");
    $stmt->execute(['id' => $employeeId]);
    $editableCount = $stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Knowledge Sharing Portal</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<?php
$isAdminView = ($roleId === ROLE_SUPER_USER || $roleId === ROLE_ADMIN);
$recentStmt = $pdo->query(
    "SELECT k.knowledge_id, k.title, k.submitted_date, c.category_name, e.employee_name
     FROM knowledge k
     JOIN categories c ON c.category_id = k.category_id
     JOIN employees e ON e.employee_id = k.employee_id
     WHERE k.status = 'Published' AND k.is_deleted = 0
     ORDER BY k.submitted_date DESC LIMIT 6"
);
$recent = $recentStmt->fetchAll();
$hour = (int)date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$firstName = explode(' ', trim($_SESSION['employee_name'] ?? ''))[0];
?>

<div class="container py-4">
    <div class="kp-hero">
        <h2><?= $greeting ?>, <?= htmlspecialchars($firstName, ENT_QUOTES, 'UTF-8') ?> 👋</h2>
        <p>
            <?php if ($roleId === ROLE_SUPER_USER): ?>
                You have full system control — no edit or delete time restrictions apply to you.
            <?php elseif ($roleId === ROLE_ADMIN): ?>
                Manage employees and keep the organization's knowledge in good shape.
            <?php else: ?>
                Share what you know — entries you publish stay editable for 7 days.
            <?php endif; ?>
        </p>
        <a href="knowledge-submit.php" class="btn btn-accent"><i class="bi bi-plus-circle me-1"></i>Share Knowledge</a>
        <a href="portal.php" class="btn btn-outline-light ms-1"><i class="bi bi-collection me-1"></i>Browse Portal</a>
    </div>

    <div class="row g-3 mb-4">
        <?php if ($isAdminView): ?>
            <div class="col-md-4">
                <div class="card kp-hover"><div class="kp-stat">
                    <div class="kp-stat-icon blue"><i class="bi bi-people-fill"></i></div>
                    <div><div class="kp-stat-label">Total Employees</div><div class="kp-stat-value"><?= (int)$totalEmployees ?></div></div>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card kp-hover"><div class="kp-stat">
                    <div class="kp-stat-icon green"><i class="bi bi-person-check-fill"></i></div>
                    <div><div class="kp-stat-label">Active Employees</div><div class="kp-stat-value"><?= (int)$activeEmployees ?></div></div>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card kp-hover"><div class="kp-stat">
                    <div class="kp-stat-icon amber"><i class="bi bi-journal-richtext"></i></div>
                    <div><div class="kp-stat-label">Knowledge Shared</div><div class="kp-stat-value"><?= (int)$totalKnowledge ?></div></div>
                </div></div>
            </div>
        <?php else: ?>
            <div class="col-md-6">
                <div class="card kp-hover"><div class="kp-stat">
                    <div class="kp-stat-icon blue"><i class="bi bi-journal-richtext"></i></div>
                    <div><div class="kp-stat-label">My Knowledge Shared</div><div class="kp-stat-value"><?= (int)$myKnowledgeCount ?></div></div>
                </div></div>
            </div>
            <div class="col-md-6">
                <div class="card kp-hover"><div class="kp-stat">
                    <div class="kp-stat-icon amber"><i class="bi bi-pencil-square"></i></div>
                    <div><div class="kp-stat-label">Still Editable (7 days)</div><div class="kp-stat-value"><?= (int)$editableCount ?></div></div>
                </div></div>
            </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5><i class="bi bi-clock-history me-2 text-primary"></i>Recently Published</h5>
            <a href="portal.php" class="btn btn-sm btn-outline-primary">View all</a>
        </div>
        <div class="list-group list-group-flush">
            <?php if (empty($recent)): ?>
                <div class="kp-empty"><i class="bi bi-inbox"></i>Nothing has been published yet.</div>
            <?php endif; ?>
            <?php foreach ($recent as $r): ?>
                <a href="knowledge-view.php?id=<?= (int)$r['knowledge_id'] ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
                    <div>
                        <div class="fw-semibold"><?= htmlspecialchars($r['title'], ENT_QUOTES, 'UTF-8') ?></div>
                        <div class="kp-meta">
                            <i class="bi bi-person"></i><?= htmlspecialchars($r['employee_name'], ENT_QUOTES, 'UTF-8') ?>
                            &nbsp;·&nbsp;<i class="bi bi-calendar3"></i><?= htmlspecialchars(date('d M Y', strtotime($r['submitted_date'])), ENT_QUOTES, 'UTF-8') ?>
                        </div>
                    </div>
                    <span class="kp-cat-badge"><?= htmlspecialchars($r['category_name'], ENT_QUOTES, 'UTF-8') ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="kp-footer">Knowledge Sharing Portal &middot; NTPC Mining Ltd. HQ, Ranchi</div>
</div>
</body>
</html>
