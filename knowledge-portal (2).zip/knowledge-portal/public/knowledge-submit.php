<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin(); // any logged-in role may submit knowledge

$pdo = Database::connect();
$categories = $pdo->query('SELECT category_id, category_name FROM categories WHERE is_active = 1 ORDER BY category_name')->fetchAll();

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $categoryId  = (int)($_POST['category_id'] ?? 0);
    $action      = $_POST['action'] ?? 'submit'; // 'draft' or 'submit'

    $titleMax = 150;

    if ($title === '' || mb_strlen($title) > $titleMax) {
        $error = "Title is required and must be under {$titleMax} characters.";
    } elseif ($description === '') {
        $error = 'Description is required.';
    } elseif ($categoryId <= 0) {
        $error = 'Please select a category.';
    } else {
        try {
            $pdo->beginTransaction();

            $employeeId = Auth::currentEmployeeId();

            // Look up the employee's department to stamp on the record
            $deptStmt = $pdo->prepare('SELECT department_id FROM employees WHERE employee_id = :id');
            $deptStmt->execute(['id' => $employeeId]);
            $departmentId = $deptStmt->fetchColumn() ?: null;

            $status = $action === 'draft' ? 'Draft' : 'Published';
            $now = new DateTimeImmutable();
            $submittedDate = $status === 'Published' ? $now->format('Y-m-d H:i:s') : null;
            $editableUntil = $status === 'Published'
                ? KnowledgeAccess::computeEditableUntil($now)->format('Y-m-d H:i:s')
                : null;

            $stmt = $pdo->prepare(
                'INSERT INTO knowledge (title, description, category_id, employee_id, department_id, status, submitted_date, editable_until)
                 VALUES (:title, :description, :category_id, :employee_id, :department_id, :status, :submitted_date, :editable_until)'
            );
            $stmt->execute([
                'title'          => $title,
                'description'    => $description,
                'category_id'    => $categoryId,
                'employee_id'    => $employeeId,
                'department_id'  => $departmentId,
                'status'         => $status,
                'submitted_date' => $submittedDate,
                'editable_until' => $editableUntil,
            ]);
            $knowledgeId = (int)$pdo->lastInsertId();

            // Handle attachments (optional, multiple)
            if (!empty($_FILES['attachments']['name'][0])) {
                $uploaded = FileUpload::handleMultiple($_FILES['attachments']);
                $attStmt = $pdo->prepare(
                    'INSERT INTO knowledge_attachments (knowledge_id, file_name, stored_name, file_path, file_type, mime_type, file_size, uploaded_by)
                     VALUES (:kid, :file_name, :stored_name, :file_path, :file_type, :mime_type, :file_size, :uploaded_by)'
                );
                foreach ($uploaded as $file) {
                    $attStmt->execute([
                        'kid'         => $knowledgeId,
                        'file_name'   => $file['file_name'],
                        'stored_name' => $file['stored_name'],
                        'file_path'   => $file['file_path'],
                        'file_type'   => $file['file_type'],
                        'mime_type'   => $file['mime_type'],
                        'file_size'   => $file['file_size'],
                        'uploaded_by' => $employeeId,
                    ]);
                }
            }

            $pdo->commit();

            ActivityLogger::log($employeeId, 'CREATE', 'Knowledge', $knowledgeId, "Created knowledge \"{$title}\" ({$status})");

            header('Location: my-knowledge.php?created=1');
            exit;

        } catch (RuntimeException $e) {
            $pdo->rollBack();
            $error = $e->getMessage(); // file validation errors are safe to show verbatim
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('Knowledge submit failed: ' . $e->getMessage());
            $error = 'Something went wrong while saving your knowledge entry. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Share Knowledge — Knowledge Sharing Portal</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-plus-circle text-primary me-2"></i>Share Knowledge</h5>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data">
                        <?= Csrf::field() ?>

                        <div class="mb-3">
                            <label class="form-label">Short Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control" maxlength="150" required
                                   value="<?= htmlspecialchars($_POST['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                   placeholder="e.g. How to Configure VPN Access">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Category <span class="text-danger">*</span></label>
                            <select name="category_id" class="form-select" required>
                                <option value="">Select category…</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= (int)$cat['category_id'] ?>">
                                        <?= htmlspecialchars($cat['category_name'], ENT_QUOTES, 'UTF-8') ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description <span class="text-danger">*</span></label>
                            <textarea name="description" id="description" class="form-control" rows="8" required
                                      placeholder="Explain the knowledge in detail…"><?= htmlspecialchars($_POST['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                            <div class="form-text">Rich text editor (bold, lists, links) can be wired in via CKEditor/TinyMCE — plain textarea shown here.</div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Attachments</label>
                            <input type="file" name="attachments[]" class="form-control" multiple
                                   accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.txt,.zip">
                            <div class="form-text">Allowed: PDF, Word, Excel, PowerPoint, images, TXT, ZIP. Max <?= MAX_UPLOAD_MB ?>MB per file.</div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" name="action" value="submit" class="btn btn-primary">Submit Knowledge</button>
                            <button type="submit" name="action" value="draft" class="btn btn-outline-secondary">Save as Draft</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
