<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireRole(ROLE_SUPER_USER);

$pdo = Database::connect();
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = trim($_POST['category_name'] ?? '');
        if ($name === '') {
            $error = 'Category name is required.';
        } else {
            try {
                $pdo->prepare('INSERT INTO categories (category_name) VALUES (:name)')->execute(['name' => $name]);
                ActivityLogger::log(Auth::currentEmployeeId(), 'CREATE', 'Category', (int)$pdo->lastInsertId(), "Added category {$name}");
            } catch (PDOException $e) {
                $error = 'That category already exists.';
            }
        }
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['category_id'] ?? 0);
        $pdo->prepare('UPDATE categories SET is_active = NOT is_active WHERE category_id = :id')->execute(['id' => $id]);
        ActivityLogger::log(Auth::currentEmployeeId(), 'UPDATE', 'Category', $id, 'Toggled category status');
    }
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY category_name')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Categories</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <h4 class="kp-page-title"><i class="bi bi-tags"></i>Categories</h4>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

    <form method="post" class="d-flex gap-2 mb-4" style="max-width:400px">
        <?= Csrf::field() ?>
        <input type="hidden" name="action" value="add">
        <input type="text" name="category_name" class="form-control" placeholder="New category name" required>
        <button type="submit" class="btn btn-primary">Add</button>
    </form>

    <table class="table bg-white">
        <thead><tr><th>Name</th><th>Status</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($categories as $cat): ?>
                <tr>
                    <td><?= htmlspecialchars($cat['category_name'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><span class="badge <?= $cat['is_active'] ? 'bg-success' : 'bg-secondary' ?>"><?= $cat['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                    <td>
                        <form method="post" class="d-inline">
                            <?= Csrf::field() ?>
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="category_id" value="<?= (int)$cat['category_id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-secondary">
                                <?= $cat['is_active'] ? 'Deactivate' : 'Activate' ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
