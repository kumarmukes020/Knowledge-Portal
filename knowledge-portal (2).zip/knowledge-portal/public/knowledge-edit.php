<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin();

$pdo = Database::connect();
$knowledgeId = (int)($_GET['id'] ?? $_POST['knowledge_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM knowledge WHERE knowledge_id = :id AND is_deleted = 0');
$stmt->execute(['id' => $knowledgeId]);
$knowledge = $stmt->fetch();

if (!$knowledge) {
    http_response_code(404);
    exit('Knowledge entry not found.');
}

// Server-side enforcement — this is the actual gate, the UI hiding the button is just a courtesy.
if (!KnowledgeAccess::canEditOrDelete($knowledge, (int)Auth::currentEmployeeId(), (int)Auth::currentRoleId())) {
    http_response_code(403);
    exit(KnowledgeAccess::EXPIRED_MESSAGE);
}

$categories = $pdo->query('SELECT category_id, category_name FROM categories WHERE is_active = 1 ORDER BY category_name')->fetchAll();
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $categoryId  = (int)($_POST['category_id'] ?? 0);

    if ($title === '' || mb_strlen($title) > 150) {
        $error = 'Title is required and must be under 150 characters.';
    } elseif ($description === '') {
        $error = 'Description is required.';
    } elseif ($categoryId <= 0) {
        $error = 'Please select a category.';
    } else {
        // Re-check the window at the moment of the actual write, not just page load —
        // closes the race where someone opens the form just inside the window and
        // submits after it has expired.
        $stmt = $pdo->prepare('SELECT * FROM knowledge WHERE knowledge_id = :id AND is_deleted = 0');
        $stmt->execute(['id' => $knowledgeId]);
        $fresh = $stmt->fetch();

        if (!$fresh || !KnowledgeAccess::canEditOrDelete($fresh, (int)Auth::currentEmployeeId(), (int)Auth::currentRoleId())) {
            http_response_code(403);
            exit(KnowledgeAccess::EXPIRED_MESSAGE);
        }

        $update = $pdo->prepare(
            'UPDATE knowledge SET title = :title, description = :description, category_id = :category_id
             WHERE knowledge_id = :id'
        );
        $update->execute([
            'title'       => $title,
            'description' => $description,
            'category_id' => $categoryId,
            'id'          => $knowledgeId,
        ]);

        // New attachments can be added during edit; existing ones are untouched here.
        if (!empty($_FILES['attachments']['name'][0])) {
            try {
                $uploaded = FileUpload::handleMultiple($_FILES['attachments']);
                $attStmt = $pdo->prepare(
                    'INSERT INTO knowledge_attachments (knowledge_id, file_name, stored_name, file_path, file_type, mime_type, file_size, uploaded_by)
                     VALUES (:kid, :file_name, :stored_name, :file_path, :file_type, :mime_type, :file_size, :uploaded_by)'
                );
                foreach ($uploaded as $file) {
                    $attStmt->execute([
                        'kid' => $knowledgeId, 'file_name' => $file['file_name'], 'stored_name' => $file['stored_name'],
                        'file_path' => $file['file_path'], 'file_type' => $file['file_type'],
                        'mime_type' => $file['mime_type'], 'file_size' => $file['file_size'],
                        'uploaded_by' => Auth::currentEmployeeId(),
                    ]);
                }
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            }
        }

        if (!$error) {
            ActivityLogger::log(Auth::currentEmployeeId(), 'UPDATE', 'Knowledge', $knowledgeId, "Updated \"{$title}\"");
            header('Location: knowledge-view.php?id=' . $knowledgeId . '&updated=1');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Knowledge</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-pencil-square text-primary me-2"></i>Edit Knowledge</h5>
                    <?php if (Auth::currentRoleId() === ROLE_EMPLOYEE): ?>
                        <span class="badge bg-warning-subtle text-warning-emphasis">
                            <?php if ($knowledge['status'] === 'Draft'): ?>
                                Draft — not yet published
                            <?php else: ?>
                                Editable until <?= htmlspecialchars(date('d M Y', strtotime($knowledge['editable_until'])), ENT_QUOTES, 'UTF-8') ?>
                            <?php endif; ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data">
                        <?= Csrf::field() ?>
                        <input type="hidden" name="knowledge_id" value="<?= $knowledgeId ?>">

                        <div class="mb-3">
                            <label class="form-label">Short Title</label>
                            <input type="text" name="title" class="form-control" maxlength="150" required
                                   value="<?= htmlspecialchars($_POST['title'] ?? $knowledge['title'], ENT_QUOTES, 'UTF-8') ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" class="form-select" required>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= (int)$cat['category_id'] ?>" <?= (int)$cat['category_id'] === (int)$knowledge['category_id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['category_name'], ENT_QUOTES, 'UTF-8') ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="8" required><?= htmlspecialchars($_POST['description'] ?? $knowledge['description'], ENT_QUOTES, 'UTF-8') ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Add More Attachments</label>
                            <input type="file" name="attachments[]" class="form-control" multiple>
                        </div>

                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <a href="knowledge-view.php?id=<?= $knowledgeId ?>" class="btn btn-outline-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
