<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin();

$pdo = Database::connect();
$employeeId = Auth::currentEmployeeId();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $currentPassword = (string)($_POST['current_password'] ?? '');
    $newPassword     = (string)($_POST['new_password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');

    $stmt = $pdo->prepare('SELECT password_hash FROM employees WHERE employee_id = :id');
    $stmt->execute(['id' => $employeeId]);
    $currentHash = $stmt->fetchColumn();

    if (!$currentHash || !password_verify($currentPassword, $currentHash)) {
        $error = 'Current password is incorrect.';
    } elseif (mb_strlen($newPassword) < 8) {
        $error = 'New password must be at least 8 characters.';
    } elseif (!preg_match('/[A-Za-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
        $error = 'New password must include both letters and numbers.';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'New password and confirmation do not match.';
    } elseif (password_verify($newPassword, $currentHash)) {
        $error = 'New password must be different from your current password.';
    } else {
        $newHash = password_hash($newPassword, PASSWORD_ARGON2ID);
        $pdo->prepare('UPDATE employees SET password_hash = :hash, must_change_password = 0 WHERE employee_id = :id')
            ->execute(['hash' => $newHash, 'id' => $employeeId]);

        ActivityLogger::log($employeeId, 'UPDATE', 'Auth', $employeeId, 'Password changed');

        // Force re-login with the new password — invalidates the current session.
        Auth::logout();
        header('Location: login.php?password_changed=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Change Password</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><i class="bi bi-key text-primary me-2"></i>Change Password</h5></div>
                <div class="card-body">
                    <?php if (!empty($_GET['forced']) && !empty($_SESSION['must_change_password'])): ?>
                        <div class="alert alert-warning">You must change your password before continuing.</div>
                    <?php endif; ?>
                    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                    <form method="post" autocomplete="off">
                        <?= Csrf::field() ?>
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" required minlength="8">
                            <div class="form-text">At least 8 characters, with letters and numbers.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required minlength="8">
                        </div>
                        <button type="submit" class="btn btn-primary">Update Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
