<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireRole(ROLE_SUPER_USER, ROLE_ADMIN);

$pdo = Database::connect();

$byDepartment = $pdo->query(
    "SELECT COALESCE(d.department_name,'Unassigned') AS label, COUNT(*) AS total
     FROM knowledge k LEFT JOIN departments d ON d.department_id = k.department_id
     WHERE k.is_deleted = 0 GROUP BY label ORDER BY total DESC"
)->fetchAll();

$byCategory = $pdo->query(
    "SELECT c.category_name AS label, COUNT(*) AS total
     FROM knowledge k JOIN categories c ON c.category_id = k.category_id
     WHERE k.is_deleted = 0 GROUP BY label ORDER BY total DESC"
)->fetchAll();

$topContributors = $pdo->query(
    "SELECT e.employee_name AS label, COUNT(*) AS total
     FROM knowledge k JOIN employees e ON e.employee_id = k.employee_id
     WHERE k.is_deleted = 0 GROUP BY label ORDER BY total DESC LIMIT 10"
)->fetchAll();

// Daily count of edit-window reminder notifications sent (from notify_expiring.php),
// last 30 days, split by type so an expiring-soon spike is distinguishable from expired notices.
$reminderTrend = $pdo->query(
    "SELECT DATE(created_at) AS day,
            SUM(type = 'expiring_soon') AS expiring_soon,
            SUM(type = 'expired') AS expired
     FROM notifications
     WHERE type IN ('expiring_soon', 'expired')
       AND created_at >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)
     GROUP BY day
     ORDER BY day ASC"
)->fetchAll();

// Fill in any gaps so the line doesn't skip days with zero reminders sent
$filledTrend = [];
$byDay = [];
foreach ($reminderTrend as $row) {
    $byDay[$row['day']] = $row;
}
$cursor = new DateTimeImmutable('-29 days');
$end = new DateTimeImmutable('today');
while ($cursor <= $end) {
    $key = $cursor->format('Y-m-d');
    $filledTrend[] = [
        'day' => $cursor->format('d M'),
        'expiring_soon' => isset($byDay[$key]) ? (int)$byDay[$key]['expiring_soon'] : 0,
        'expired' => isset($byDay[$key]) ? (int)$byDay[$key]['expired'] : 0,
    ];
    $cursor = $cursor->modify('+1 day');
}

// CSV export
if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="knowledge_contribution_report.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Employee', 'Department', 'Category', 'Title', 'Status', 'Submitted Date']);

    $rows = $pdo->query(
        "SELECT e.employee_name, d.department_name, c.category_name, k.title, k.status, k.submitted_date
         FROM knowledge k
         JOIN employees e ON e.employee_id = k.employee_id
         JOIN categories c ON c.category_id = k.category_id
         LEFT JOIN departments d ON d.department_id = k.department_id
         WHERE k.is_deleted = 0
         ORDER BY k.submitted_date DESC"
    )->fetchAll();

    foreach ($rows as $r) {
        fputcsv($out, [$r['employee_name'], $r['department_name'], $r['category_name'], $r['title'], $r['status'], $r['submitted_date']]);
    }
    fclose($out);
    ActivityLogger::log(Auth::currentEmployeeId(), 'EXPORT', 'Reports', null, 'Exported knowledge contribution CSV');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reports</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0 kp-page-title"><i class="bi bi-graph-up-arrow"></i>Knowledge Contribution Reports</h4>
        <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export to Excel/CSV</a>
    </div>

    <div class="row g-3">
        <div class="col-md-6">
            <div class="card kp-hover"><div class="card-body">
                <h6>Knowledge by Department</h6>
                <canvas id="deptChart" height="200"></canvas>
            </div></div>
        </div>
        <div class="col-md-6">
            <div class="card kp-hover"><div class="card-body">
                <h6>Knowledge by Category</h6>
                <canvas id="catChart" height="200"></canvas>
            </div></div>
        </div>
        <div class="col-md-12">
            <div class="card kp-hover"><div class="card-body">
                <h6>Top Contributors</h6>
                <canvas id="contribChart" height="120"></canvas>
            </div></div>
        </div>
        <div class="col-md-12">
            <div class="card kp-hover"><div class="card-body">
                <h6>Edit-Window Reminder Notifications Sent — Last 30 Days</h6>
                <div class="text-muted small mb-2">Count of knowledge entries flagged by the reminder job (scripts/notify_expiring.php), not actual emails sent.</div>
                <canvas id="reminderTrendChart" height="90"></canvas>
            </div></div>
        </div>
    </div>
</div>

<script>
const deptData = <?= json_encode($byDepartment) ?>;
const catData = <?= json_encode($byCategory) ?>;
const contribData = <?= json_encode($topContributors) ?>;
const reminderTrendData = <?= json_encode($filledTrend) ?>;

new Chart(document.getElementById('deptChart'), {
    type: 'pie',
    data: { labels: deptData.map(d => d.label), datasets: [{ data: deptData.map(d => d.total) }] }
});
new Chart(document.getElementById('catChart'), {
    type: 'pie',
    data: { labels: catData.map(d => d.label), datasets: [{ data: catData.map(d => d.total) }] }
});
new Chart(document.getElementById('contribChart'), {
    type: 'bar',
    data: { labels: contribData.map(d => d.label), datasets: [{ label: 'Knowledge Shared', data: contribData.map(d => d.total) }] },
    options: { indexAxis: 'y' }
});
new Chart(document.getElementById('reminderTrendChart'), {
    type: 'line',
    data: {
        labels: reminderTrendData.map(d => d.day),
        datasets: [
            {
                label: 'Expiring Soon (24h warning)',
                data: reminderTrendData.map(d => d.expiring_soon),
                borderColor: '#f0ad4e',
                backgroundColor: 'rgba(240,173,78,0.15)',
                tension: 0.3,
                fill: true,
            },
            {
                label: 'Window Expired',
                data: reminderTrendData.map(d => d.expired),
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220,53,69,0.1)',
                tension: 0.3,
                fill: true,
            },
        ],
    },
    options: {
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
        interaction: { mode: 'index', intersect: false },
    },
});
</script>
</body>
</html>
