<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
// Publicly viewable when Published — no login required. Non-published entries
// (Draft/Submitted/Archived) still require the author or an Admin/Super User.

$pdo = Database::connect();
$knowledgeId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT k.*, c.category_name, d.department_name, e.employee_name
     FROM knowledge k
     JOIN categories c ON c.category_id = k.category_id
     JOIN employees e  ON e.employee_id = k.employee_id
     LEFT JOIN departments d ON d.department_id = k.department_id
     WHERE k.knowledge_id = :id AND k.is_deleted = 0'
);
$stmt->execute(['id' => $knowledgeId]);
$knowledge = $stmt->fetch();

if (!$knowledge) {
    http_response_code(404);
    exit('Knowledge entry not found.');
}

$isLoggedIn = Auth::isLoggedIn();
$isOwner = $isLoggedIn && $knowledge['employee_id'] == Auth::currentEmployeeId();
$isPrivileged = $isLoggedIn && in_array(Auth::currentRoleId(), [ROLE_SUPER_USER, ROLE_ADMIN], true);
$isPublished = $knowledge['status'] === 'Published';

// Published entries are public. Anything else (Draft/Submitted/Archived) is
// visible only to its author or an Admin/Super User — explicitly denied by
// default, so an anonymous visitor can never see an unpublished entry.
if (!$isPublished && !$isOwner && !$isPrivileged) {
    http_response_code(403);
    exit($isLoggedIn ? 'This knowledge entry is not yet published.' : 'This knowledge entry is not yet published. Please log in if you believe you should have access.');
}

$pdo->prepare('UPDATE knowledge SET view_count = view_count + 1 WHERE knowledge_id = :id')->execute(['id' => $knowledgeId]);

$attStmt = $pdo->prepare('SELECT * FROM knowledge_attachments WHERE knowledge_id = :id ORDER BY uploaded_date');
$attStmt->execute(['id' => $knowledgeId]);
$attachments = $attStmt->fetchAll();

$canEditDelete = KnowledgeAccess::canEditOrDelete($knowledge, (int)Auth::currentEmployeeId(), (int)Auth::currentRoleId());

function formatBytes(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 1) . ' KB';
    return $bytes . ' B';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($knowledge['title'], ENT_QUOTES, 'UTF-8') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <a href="portal.php" class="text-decoration-none small d-inline-block mb-3"><i class="bi bi-arrow-left me-1"></i>Back to Knowledge Portal</a>
            <div class="card">
                <div class="card-body p-4 p-md-5">
                    <span class="kp-cat-badge"><?= htmlspecialchars($knowledge['category_name'], ENT_QUOTES, 'UTF-8') ?></span>
                    <?php if (!$isPublished): ?>
                        <span class="badge bg-warning-subtle text-warning-emphasis ms-1"><?= htmlspecialchars($knowledge['status'], ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>

                    <h3 class="mt-3 mb-3"><?= htmlspecialchars($knowledge['title'], ENT_QUOTES, 'UTF-8') ?></h3>
                    <div class="kp-meta mb-4 d-flex flex-wrap gap-3">
                        <span><i class="bi bi-person-circle"></i><?= htmlspecialchars($knowledge['employee_name'], ENT_QUOTES, 'UTF-8') ?><?php if ($knowledge['department_name']): ?> &middot; <?= htmlspecialchars($knowledge['department_name'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?></span>
                        <?php if ($knowledge['submitted_date']): ?>
                            <span><i class="bi bi-calendar3"></i><?= htmlspecialchars(date('d M Y, g:i A', strtotime($knowledge['submitted_date'])), ENT_QUOTES, 'UTF-8') ?></span>
                        <?php endif; ?>
                        <span><i class="bi bi-eye"></i><?= (int)$knowledge['view_count'] ?> views</span>
                    </div>

                    <hr>
                    <div class="kp-detail-body mb-4">
                        <?= nl2br(htmlspecialchars($knowledge['description'], ENT_QUOTES, 'UTF-8')) ?>
                    </div>

                    <?php if ($attachments): ?>
                        <h6 class="mb-3"><i class="bi bi-paperclip me-1"></i>Attachments (<?= count($attachments) ?>)</h6>
                        <ul class="list-group mb-3">
                            <?php foreach ($attachments as $a): ?>
                                <li class="list-group-item kp-attach-item d-flex justify-content-between align-items-center py-3">
                                    <span class="d-flex align-items-center">
                                        <span class="kp-file-icon"><i class="bi bi-file-earmark-text"></i></span>
                                        <span>
                                            <span class="fw-semibold d-block"><?= htmlspecialchars($a['file_name'], ENT_QUOTES, 'UTF-8') ?></span>
                                            <span class="kp-meta"><?= strtoupper(htmlspecialchars($a['file_type'], ENT_QUOTES, 'UTF-8')) ?> &middot; <?= formatBytes((int)$a['file_size']) ?></span>
                                        </span>
                                    </span>
                                    <a href="download.php?id=<?= (int)$a['attachment_id'] ?>" class="btn btn-sm btn-primary"><i class="bi bi-download me-1"></i>Download</a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                    <?php if ($isOwner || Auth::isSuperUser() || Auth::currentRoleId() === ROLE_ADMIN): ?>
                        <hr>
                        <?php if ($canEditDelete): ?>
                            <a href="knowledge-edit.php?id=<?= $knowledgeId ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                            <?php if ($knowledge['status'] === 'Draft'): ?>
                                <form method="post" action="knowledge-publish.php" class="d-inline"
                                      onsubmit="return confirm('Publish this knowledge entry? It will become visible in the public Knowledge Portal and start its 7-day edit window.');">
                                    <?= Csrf::field() ?>
                                    <input type="hidden" name="knowledge_id" value="<?= $knowledgeId ?>">
                                    <button type="submit" class="btn btn-sm btn-primary">Publish</button>
                                </form>
                            <?php endif; ?>
                            <form method="post" action="knowledge-delete.php" class="d-inline"
                                  onsubmit="return confirm('Delete this knowledge entry? This cannot be undone.');">
                                <?= Csrf::field() ?>
                                <input type="hidden" name="knowledge_id" value="<?= $knowledgeId ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        <?php elseif ($isOwner): ?>
                            <div class="alert alert-secondary small mb-0"><?= KnowledgeAccess::EXPIRED_MESSAGE ?></div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
