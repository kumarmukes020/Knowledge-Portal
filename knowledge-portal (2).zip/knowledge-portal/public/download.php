<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
// Publicly downloadable when the parent knowledge entry is Published — no
// login required. Anything else still requires the author or Admin/Super User.

$pdo = Database::connect();
$attachmentId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT a.*, k.status, k.employee_id, k.is_deleted
     FROM knowledge_attachments a
     JOIN knowledge k ON k.knowledge_id = a.knowledge_id
     WHERE a.attachment_id = :id'
);
$stmt->execute(['id' => $attachmentId]);
$att = $stmt->fetch();

if (!$att || (int)$att['is_deleted'] === 1) {
    http_response_code(404);
    exit('File not found.');
}

$isOwner = (int)$att['employee_id'] === Auth::currentEmployeeId();
$isPrivileged = in_array(Auth::currentRoleId(), [ROLE_SUPER_USER, ROLE_ADMIN], true);

if ($att['status'] !== 'Published' && !$isOwner && !$isPrivileged) {
    http_response_code(403);
    exit('You do not have access to this file.');
}

$fullPath = realpath(__DIR__ . '/' . $att['file_path']);
$uploadsRoot = realpath(UPLOAD_DIR);

// Defense in depth: confirm resolved path is actually inside the uploads directory
if ($fullPath === false || $uploadsRoot === false || strpos($fullPath, $uploadsRoot) !== 0 || !is_file($fullPath)) {
    http_response_code(404);
    exit('File not found.');
}

ActivityLogger::log(Auth::currentEmployeeId(), 'DOWNLOAD', 'Attachment', $attachmentId, "Downloaded {$att['file_name']}");

header('Content-Description: File Transfer');
header('Content-Type: ' . $att['mime_type']);
header('Content-Disposition: attachment; filename="' . basename($att['file_name']) . '"');
header('Content-Length: ' . filesize($fullPath));
header('X-Content-Type-Options: nosniff');
readfile($fullPath);
exit;
