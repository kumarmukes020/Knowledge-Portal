<?php
/** Expects Auth::start() already called by the including page. */
$isLoggedIn = Auth::isLoggedIn();
$roleId = Auth::currentRoleId();
$currentPage = basename($_SERVER['SCRIPT_NAME']);

function navActive(string $page, string $current): string {
    return $page === $current ? 'active' : '';
}
$empName = $_SESSION['employee_name'] ?? '';
$initial = $empName !== '' ? strtoupper(mb_substr($empName, 0, 1)) : '?';
?>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top kp-navbar">
    <div class="container-fluid px-lg-4">
        <a class="navbar-brand" href="<?= $isLoggedIn ? 'dashboard.php' : 'portal.php' ?>">
            <span class="kp-brand-icon"><i class="bi bi-lightbulb-fill"></i></span>
            <span>Knowledge Portal</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav me-auto ms-lg-3">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item"><a class="nav-link <?= navActive('dashboard.php', $currentPage) ?>" href="dashboard.php"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a></li>
                <?php endif; ?>
                <li class="nav-item"><a class="nav-link <?= navActive('portal.php', $currentPage) ?>" href="portal.php"><i class="bi bi-collection me-1"></i>Knowledge Portal</a></li>
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item"><a class="nav-link <?= navActive('knowledge-submit.php', $currentPage) ?>" href="knowledge-submit.php"><i class="bi bi-plus-circle me-1"></i>Share Knowledge</a></li>
                    <li class="nav-item"><a class="nav-link <?= navActive('my-knowledge.php', $currentPage) ?>" href="my-knowledge.php"><i class="bi bi-journal-text me-1"></i>My Knowledge</a></li>
                    <?php if ($roleId === ROLE_SUPER_USER || $roleId === ROLE_ADMIN): ?>
                        <li class="nav-item"><a class="nav-link <?= navActive('employees.php', $currentPage) ?>" href="employees.php"><i class="bi bi-people me-1"></i>Employees</a></li>
                        <li class="nav-item"><a class="nav-link <?= navActive('reports.php', $currentPage) ?>" href="reports.php"><i class="bi bi-graph-up-arrow me-1"></i>Reports</a></li>
                    <?php endif; ?>
                    <?php if ($roleId === ROLE_SUPER_USER): ?>
                        <li class="nav-item"><a class="nav-link <?= navActive('categories.php', $currentPage) ?>" href="categories.php"><i class="bi bi-tags me-1"></i>Categories</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <div class="d-flex align-items-center text-white mt-2 mt-lg-0">
                <?php if ($isLoggedIn): ?>
                    <span class="kp-user-chip" title="<?= htmlspecialchars($empName, ENT_QUOTES, 'UTF-8') ?>">
                        <span class="kp-avatar"><?= htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') ?></span>
                        <span class="kp-user-name"><?= htmlspecialchars($empName, ENT_QUOTES, 'UTF-8') ?></span>
                        <span class="kp-role-badge"><?= htmlspecialchars($_SESSION['role_name'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                    </span>
                    <a href="change-password.php" class="btn btn-outline-light btn-sm me-2" title="Change Password"><i class="bi bi-key"></i></a>
                    <a href="logout.php" class="btn btn-accent btn-sm"><i class="bi bi-box-arrow-right me-1"></i><span class="kp-btn-label">Logout</span></a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-accent btn-sm"><i class="bi bi-box-arrow-in-right me-1"></i>Employee Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
