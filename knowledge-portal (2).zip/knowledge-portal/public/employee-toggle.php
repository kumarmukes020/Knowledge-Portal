<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireRole(ROLE_SUPER_USER);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
Csrf::requireValid();

$pdo = Database::connect();
$employeeId = (int)($_POST['employee_id'] ?? 0);

if ($employeeId === Auth::currentEmployeeId()) {
    http_response_code(400);
    exit('You cannot deactivate your own account.');
}

$stmt = $pdo->prepare('SELECT status, employee_name FROM employees WHERE employee_id = :id');
$stmt->execute(['id' => $employeeId]);
$employee = $stmt->fetch();

if (!$employee) {
    http_response_code(404);
    exit('Employee not found.');
}

$newStatus = $employee['status'] === 'Active' ? 'Inactive' : 'Active';
$pdo->prepare('UPDATE employees SET status = :status WHERE employee_id = :id')
    ->execute(['status' => $newStatus, 'id' => $employeeId]);

// Inactive employees lose any active session immediately
if ($newStatus === 'Inactive') {
    $pdo->prepare('DELETE FROM sessions WHERE employee_id = :id')->execute(['id' => $employeeId]);
}

ActivityLogger::log(Auth::currentEmployeeId(), 'UPDATE', 'Employee', $employeeId, "Set {$employee['employee_name']} to {$newStatus}");

header('Location: employees.php');
exit;
