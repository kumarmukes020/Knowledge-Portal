<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireLogin();

$pdo = Database::connect();
$employeeId = Auth::currentEmployeeId();
$roleId = Auth::currentRoleId();

$stmt = $pdo->prepare(
    'SELECT k.*, c.category_name
     FROM knowledge k
     JOIN categories c ON c.category_id = k.category_id
     WHERE k.employee_id = :id AND k.is_deleted = 0
     ORDER BY k.created_at DESC'
);
$stmt->execute(['id' => $employeeId]);
$items = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Knowledge</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <h4 class="kp-page-title"><i class="bi bi-journal-text"></i>My Knowledge</h4>

    <?php if (!empty($_GET['created'])): ?><div class="alert alert-success">Knowledge saved successfully.</div><?php endif; ?>
    <?php if (!empty($_GET['deleted'])): ?><div class="alert alert-success">Knowledge deleted.</div><?php endif; ?>
    <?php if (!empty($_GET['published'])): ?><div class="alert alert-success">Knowledge published — it's now live in the Knowledge Portal.</div><?php endif; ?>

    <div class="table-responsive">
        <table class="table table-hover bg-white">
            <thead>
                <tr>
                    <th>Title</th><th>Category</th><th>Status</th><th>Submitted</th><th>Editable Until</th><th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <?php
                        $canEdit = KnowledgeAccess::canEditOrDelete($item, $employeeId, $roleId);
                    ?>
                    <tr>
                        <td><a href="knowledge-view.php?id=<?= (int)$item['knowledge_id'] ?>"><?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?></a></td>
                        <td><?= htmlspecialchars($item['category_name'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><span class="badge bg-secondary"><?= htmlspecialchars($item['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
                        <td><?= $item['submitted_date'] ? htmlspecialchars(date('d M Y', strtotime($item['submitted_date'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                        <td>
                            <?php if ($item['editable_until']): ?>
                                <?= htmlspecialchars(date('d M Y', strtotime($item['editable_until'])), ENT_QUOTES, 'UTF-8') ?>
                                <?php if (!$canEdit && $roleId === ROLE_EMPLOYEE): ?>
                                    <span class="badge bg-danger-subtle text-danger-emphasis">Expired</span>
                                <?php endif; ?>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td>
                            <?php if ($canEdit): ?>
                                <a href="knowledge-edit.php?id=<?= (int)$item['knowledge_id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                            <?php endif; ?>
                            <?php if ($item['status'] === 'Draft' && $canEdit): ?>
                                <form method="post" action="knowledge-publish.php" class="d-inline"
                                      onsubmit="return confirm('Publish this knowledge entry? It will become visible in the public Knowledge Portal and start its 7-day edit window.');">
                                    <?= Csrf::field() ?>
                                    <input type="hidden" name="knowledge_id" value="<?= (int)$item['knowledge_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-primary">Publish</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($items)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">You haven't shared any knowledge yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
