<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireRole(ROLE_SUPER_USER, ROLE_ADMIN);

$pdo = Database::connect();
$departments = $pdo->query('SELECT department_id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name')->fetchAll();
$locations   = $pdo->query('SELECT location_id, location_name FROM locations WHERE is_active = 1 ORDER BY location_name')->fetchAll();
$grades      = $pdo->query('SELECT grade_id, grade_code FROM employee_grades ORDER BY grade_code')->fetchAll();

$error = null;
$generatedPassword = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $employeeNumber = trim($_POST['employee_number'] ?? '');
    $employeeName   = trim($_POST['employee_name'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $username       = trim($_POST['username'] ?? '');
    $mobile         = trim($_POST['mobile_number'] ?? '');
    $gradeId        = (int)($_POST['grade_id'] ?? 0) ?: null;
    $locationId     = (int)($_POST['location_id'] ?? 0) ?: null;
    $departmentId   = (int)($_POST['department_id'] ?? 0) ?: null;
    $roleId         = (int)($_POST['role_id'] ?? ROLE_EMPLOYEE);

    // Only Super User can create Admin or Super User accounts.
    if (!Auth::isSuperUser() && $roleId !== ROLE_EMPLOYEE) {
        $roleId = ROLE_EMPLOYEE;
    }

    if ($employeeNumber === '' || $employeeName === '' || $email === '' || $username === '') {
        $error = 'Employee number, name, email, and username are all required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Uniqueness check — race-safe fallback is the DB UNIQUE constraint caught below too.
        $check = $pdo->prepare('SELECT COUNT(*) FROM employees WHERE employee_number = :num OR email = :email OR username = :user');
        $check->execute(['num' => $employeeNumber, 'email' => $email, 'user' => $username]);

        if ($check->fetchColumn() > 0) {
            $error = 'Employee number, email, or username is already in use.';
        } else {
            try {
                $tempPassword = bin2hex(random_bytes(6)); // 12-char temp password, shown once
                $hash = password_hash($tempPassword, PASSWORD_ARGON2ID);

                $stmt = $pdo->prepare(
                    'INSERT INTO employees
                        (employee_number, employee_name, grade_id, location_id, department_id, mobile_number, email, username, password_hash, role_id, status, created_by)
                     VALUES
                        (:num, :name, :grade, :loc, :dept, :mobile, :email, :username, :hash, :role, "Active", :created_by)'
                );
                $stmt->execute([
                    'num' => $employeeNumber, 'name' => $employeeName, 'grade' => $gradeId,
                    'loc' => $locationId, 'dept' => $departmentId, 'mobile' => $mobile ?: null,
                    'email' => $email, 'username' => $username, 'hash' => $hash,
                    'role' => $roleId, 'created_by' => Auth::currentEmployeeId(),
                ]);

                $newId = (int)$pdo->lastInsertId();
                ActivityLogger::log(Auth::currentEmployeeId(), 'CREATE', 'Employee', $newId, "Created employee {$employeeName} ({$employeeNumber})");

                $generatedPassword = $tempPassword; // shown once so it can be shared securely out-of-band

            } catch (PDOException $e) {
                $error = 'Could not create employee — number, email, or username may already exist.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Employee</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><i class="bi bi-person-plus text-primary me-2"></i>Add Employee</h5></div>
                <div class="card-body">
                    <?php if ($generatedPassword): ?>
                        <div class="alert alert-success">
                            Employee created. Temporary password (share securely, not by plain email):
                            <code><?= htmlspecialchars($generatedPassword, ENT_QUOTES, 'UTF-8') ?></code>
                        </div>
                        <a href="employees.php" class="btn btn-primary btn-sm">Back to Employee List</a>
                    <?php else: ?>
                        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                        <form method="post">
                            <?= Csrf::field() ?>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Employee Number</label>
                                    <input type="text" name="employee_number" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="employee_name" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Username</label>
                                    <input type="text" name="username" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Mobile Number</label>
                                    <input type="text" name="mobile_number" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Grade</label>
                                    <select name="grade_id" class="form-select">
                                        <option value="">—</option>
                                        <?php foreach ($grades as $g): ?>
                                            <option value="<?= (int)$g['grade_id'] ?>"><?= htmlspecialchars($g['grade_code'], ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Department</label>
                                    <select name="department_id" class="form-select">
                                        <option value="">—</option>
                                        <?php foreach ($departments as $d): ?>
                                            <option value="<?= (int)$d['department_id'] ?>"><?= htmlspecialchars($d['department_name'], ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Location</label>
                                    <select name="location_id" class="form-select">
                                        <option value="">—</option>
                                        <?php foreach ($locations as $l): ?>
                                            <option value="<?= (int)$l['location_id'] ?>"><?= htmlspecialchars($l['location_name'], ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php if (Auth::isSuperUser()): ?>
                                <div class="col-md-6">
                                    <label class="form-label">Role</label>
                                    <select name="role_id" class="form-select">
                                        <option value="3">Employee</option>
                                        <option value="2">Admin</option>
                                        <option value="1">Super User</option>
                                    </select>
                                </div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Create Employee</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
