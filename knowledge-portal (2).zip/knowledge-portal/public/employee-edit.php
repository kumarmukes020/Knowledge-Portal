<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
Auth::start();
Auth::requireRole(ROLE_SUPER_USER, ROLE_ADMIN);

$pdo = Database::connect();
$employeeId = (int)($_GET['id'] ?? $_POST['employee_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM employees WHERE employee_id = :id');
$stmt->execute(['id' => $employeeId]);
$employee = $stmt->fetch();

if (!$employee) {
    http_response_code(404);
    exit('Employee not found.');
}

// Admin cannot edit a Super User or promote anyone to Super User.
if (!Auth::isSuperUser() && (int)$employee['role_id'] === ROLE_SUPER_USER) {
    http_response_code(403);
    exit('Only a Super User can edit this account.');
}

$departments = $pdo->query('SELECT department_id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name')->fetchAll();
$locations   = $pdo->query('SELECT location_id, location_name FROM locations WHERE is_active = 1 ORDER BY location_name')->fetchAll();

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $employeeName = trim($_POST['employee_name'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $mobile       = trim($_POST['mobile_number'] ?? '');
    $departmentId = (int)($_POST['department_id'] ?? 0) ?: null;
    $locationId   = (int)($_POST['location_id'] ?? 0) ?: null;
    $roleId       = Auth::isSuperUser() ? (int)($_POST['role_id'] ?? $employee['role_id']) : $employee['role_id'];

    if ($employeeName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'A valid name and email are required.';
    } else {
        $stmt = $pdo->prepare(
            'UPDATE employees SET employee_name = :name, email = :email, mobile_number = :mobile,
             department_id = :dept, location_id = :loc, role_id = :role WHERE employee_id = :id'
        );
        $stmt->execute([
            'name' => $employeeName, 'email' => $email, 'mobile' => $mobile ?: null,
            'dept' => $departmentId, 'loc' => $locationId, 'role' => $roleId, 'id' => $employeeId,
        ]);

        ActivityLogger::log(Auth::currentEmployeeId(), 'UPDATE', 'Employee', $employeeId, "Updated employee {$employeeName}");
        header('Location: employees.php?updated=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Employee</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header"><h5 class="mb-0">Edit Employee — <?= htmlspecialchars($employee['employee_number'], ENT_QUOTES, 'UTF-8') ?></h5></div>
                <div class="card-body">
                    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                    <form method="post">
                        <?= Csrf::field() ?>
                        <input type="hidden" name="employee_id" value="<?= $employeeId ?>">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Full Name</label>
                                <input type="text" name="employee_name" class="form-control" required
                                       value="<?= htmlspecialchars($employee['employee_name'], ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required
                                       value="<?= htmlspecialchars($employee['email'], ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Mobile Number</label>
                                <input type="text" name="mobile_number" class="form-control"
                                       value="<?= htmlspecialchars($employee['mobile_number'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Department</label>
                                <select name="department_id" class="form-select">
                                    <option value="">—</option>
                                    <?php foreach ($departments as $d): ?>
                                        <option value="<?= (int)$d['department_id'] ?>" <?= (int)$d['department_id'] === (int)$employee['department_id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($d['department_name'], ENT_QUOTES, 'UTF-8') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Location</label>
                                <select name="location_id" class="form-select">
                                    <option value="">—</option>
                                    <?php foreach ($locations as $l): ?>
                                        <option value="<?= (int)$l['location_id'] ?>" <?= (int)$l['location_id'] === (int)$employee['location_id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($l['location_name'], ENT_QUOTES, 'UTF-8') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php if (Auth::isSuperUser()): ?>
                            <div class="col-md-6">
                                <label class="form-label">Role</label>
                                <select name="role_id" class="form-select">
                                    <option value="3" <?= (int)$employee['role_id'] === 3 ? 'selected' : '' ?>>Employee</option>
                                    <option value="2" <?= (int)$employee['role_id'] === 2 ? 'selected' : '' ?>>Admin</option>
                                    <option value="1" <?= (int)$employee['role_id'] === 1 ? 'selected' : '' ?>>Super User</option>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3">Save Changes</button>
                        <a href="employees.php" class="btn btn-outline-secondary mt-3">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
