-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2026 at 12:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knowledge_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `record_id` int(10) UNSIGNED DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`log_id`, `employee_id`, `action`, `module`, `record_id`, `description`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:40:49'),
(2, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #2', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:40:51'),
(3, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #3', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:41:00'),
(4, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #4', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:42:00'),
(5, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #5', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:42:24'),
(6, 1, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:57:46'),
(7, 1, 'CREATE', 'Employee', 2, 'Created employee MUKESH KUMAR (100001)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 15:59:42'),
(8, 1, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:00:00'),
(9, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:00:10'),
(10, 2, 'CREATE', 'Knowledge', 1, 'Created knowledge \"TEst\" (Draft)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:01:18'),
(11, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:04:37'),
(12, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:04:40'),
(13, 1, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:04:45'),
(14, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:09:09'),
(15, 2, 'UPDATE', 'Knowledge', 1, 'Published \"TEst\"', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:10:44'),
(16, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:11:10'),
(17, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:11:27'),
(18, 2, 'UPDATE', 'Knowledge', 1, 'Updated \"TEst\"', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:11:42'),
(19, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:12:06'),
(20, 1, 'CREATE', 'Employee', 3, 'Created employee admin1 (admin)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:13:26'),
(21, 1, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:13:41'),
(22, 3, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:13:47'),
(23, 3, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:14:08'),
(24, 1, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:14:09'),
(25, 1, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-21 16:14:14'),
(26, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:16:44'),
(27, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:17:11'),
(28, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:17:12'),
(29, 2, 'UPDATE', 'Auth', 2, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:17:26'),
(30, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:17:26'),
(31, 2, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:17:46'),
(32, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:17:54'),
(33, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:18:34'),
(34, 3, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:18:52'),
(35, 3, 'UPDATE', 'Auth', 3, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:19:43'),
(36, 3, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:19:43'),
(37, 3, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:19:56'),
(38, 3, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:20:15'),
(39, 2, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:21:11'),
(40, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:21:17'),
(41, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:21:35'),
(42, 2, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:21:58'),
(43, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:22:03'),
(44, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:22:05'),
(45, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:22:49'),
(46, 2, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:22:51'),
(47, 1, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:23:10'),
(48, 1, 'UPDATE', 'Auth', 1, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:23:40'),
(49, 1, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:23:40'),
(50, 1, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:24:08'),
(51, 1, 'LOGOUT', 'Auth', NULL, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:24:36'),
(52, 2, 'LOGIN_FAILED', 'Auth', NULL, 'Failed attempt #1', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:25:43'),
(53, 2, 'LOGIN', 'Auth', NULL, 'Successful login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:25:52'),
(54, 2, 'CREATE', 'Knowledge', 2, 'Created knowledge \"ग्लेशियर नेशनल पार्क\" (Published)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:26:17'),
(55, 2, 'DELETE', 'Knowledge', 2, 'Deleted \"ग्लेशियर नेशनल पार्क\"', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:26:46'),
(56, 2, 'CREATE', 'Knowledge', 3, 'Created knowledge \"ग्लेशियर नेशनल पार्क\" (Draft)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:27:10'),
(57, 2, 'UPDATE', 'Knowledge', 3, 'Published \"ग्लेशियर नेशनल पार्क\"', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0', '2026-08-21 16:27:12');

-- --------------------------------------------------------

--
-- Table structure for table `admin_permissions`
--

CREATE TABLE `admin_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(10) UNSIGNED NOT NULL,
  `module_key` varchar(50) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `is_active`, `created_at`) VALUES
(1, 'IT', 1, '2026-08-21 15:30:03'),
(2, 'HR', 1, '2026-08-21 15:30:03'),
(3, 'Finance', 1, '2026-08-21 15:30:03'),
(4, 'Legal', 1, '2026-08-21 15:30:03'),
(5, 'Contracts', 1, '2026-08-21 15:30:03'),
(6, 'Mining', 1, '2026-08-21 15:30:03'),
(7, 'Safety', 1, '2026-08-21 15:30:03'),
(8, 'Environment', 1, '2026-08-21 15:30:03'),
(9, 'Projects', 1, '2026-08-21 15:30:03'),
(10, 'R&R', 1, '2026-08-21 15:30:03'),
(11, 'Procurement', 1, '2026-08-21 15:30:03'),
(12, 'General', 1, '2026-08-21 15:30:03');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `is_active`, `created_at`) VALUES
(1, 'Information Technology', 1, '2026-08-21 15:30:02'),
(2, 'Administration', 1, '2026-08-21 15:30:02');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(10) UNSIGNED NOT NULL,
  `employee_number` varchar(20) NOT NULL,
  `employee_name` varchar(150) NOT NULL,
  `grade_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `location_id` int(10) UNSIGNED DEFAULT NULL,
  `department_id` int(10) UNSIGNED DEFAULT NULL,
  `mobile_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1,
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `failed_login_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `employee_number`, `employee_name`, `grade_id`, `location_id`, `department_id`, `mobile_number`, `email`, `username`, `password_hash`, `must_change_password`, `role_id`, `status`, `failed_login_attempts`, `locked_until`, `last_login_at`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'SU0001', 'System Administrator', NULL, 1, 1, NULL, 'admin@gmail.com', 'superuser', '$argon2id$v=19$m=65536,t=4,p=1$YWFjVGpjVjZxalg0cXJUZg$xGq2FjhhcSQy36UO5wh3gt6B/dllWFThJuqIReqUDcw', 0, 1, 'Active', 0, NULL, '2026-08-21 16:24:08', NULL, '2026-08-21 15:30:03', '2026-08-21 16:24:08'),
(2, '100001', 'MUKESH KUMAR', 3, 1, 1, '7894561230', 'mukesh@gmail.com', 'mukesh', '$argon2id$v=19$m=65536,t=4,p=1$bkMzd0hHNnBmMmwvLlN6bw$TTkCxbVqvJcNt81/HbLG04+GrfoU9bDS32bjtNJmm6U', 0, 3, 'Active', 0, NULL, '2026-08-21 16:25:52', 1, '2026-08-21 15:59:42', '2026-08-21 16:25:52'),
(3, 'admin', 'admin1', 2, 1, 1, '123321232', 'admin1@gmail.com', 'admin1', '$argon2id$v=19$m=65536,t=4,p=1$WW9LLk5VbHRsZWlsTzg4cw$Xsqyy1LC+bbkpkFRlodPlim9mSUQt5xuwehoWgPbaPk', 0, 2, 'Active', 0, NULL, '2026-08-21 16:19:56', 1, '2026-08-21 16:13:26', '2026-08-21 16:19:56');

-- --------------------------------------------------------

--
-- Table structure for table `employee_grades`
--

CREATE TABLE `employee_grades` (
  `grade_id` tinyint(3) UNSIGNED NOT NULL,
  `grade_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_grades`
--

INSERT INTO `employee_grades` (`grade_id`, `grade_code`) VALUES
(1, 'E1'),
(2, 'E2'),
(3, 'E3'),
(4, 'E4'),
(5, 'E5'),
(6, 'E6'),
(7, 'E7'),
(8, 'E8'),
(9, 'E9');

-- --------------------------------------------------------

--
-- Table structure for table `knowledge`
--

CREATE TABLE `knowledge` (
  `knowledge_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(10) UNSIGNED NOT NULL,
  `department_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('Draft','Submitted','Published','Archived','Deleted') NOT NULL DEFAULT 'Draft',
  `submitted_date` datetime DEFAULT NULL,
  `editable_until` datetime DEFAULT NULL,
  `view_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `knowledge`
--

INSERT INTO `knowledge` (`knowledge_id`, `title`, `description`, `category_id`, `employee_id`, `department_id`, `status`, `submitted_date`, `editable_until`, `view_count`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 'TEst', 'TEST ABC xfhfgn cfnfgnbftth', 1, 2, 1, 'Published', '2026-08-21 12:40:44', '2026-08-28 12:40:44', 11, 0, '2026-08-21 16:01:18', '2026-08-21 16:24:49'),
(2, 'ग्लेशियर नेशनल पार्क', 'ग्लेशियर नेशनल पार्क (अंग्रेज़ी: Glacier National Park; उच्चा.: ग्लेशियर नेशनल पार्क) अमेरिकी राष्ट्रीय उद्यान है, जो कनाडा-संयुक्त राज्य अमेरिका की सीमा के उत्तर-पश्चिमी मोंटाना राज्य में स्थित है और कनाडा की ओर अल्बर्टा और ब्रिटिश कोलम्बिया प्रांतों से सटा हुआ है। यह उद्यान दस लाख एकड़ (4,000 किमी2) से अधिक क्षेत्र में फैला हुआ है और इसमें दो पर्वत श्रृंखलाएँ (रॉकी पर्वत की उप-श्रेणियाँ), 130 से अधिक नामित झीलें, 1,000 से अधिक विभिन्न पौधों की प्रजातियाँ और वन्यजीवों की सैकड़ों प्रजातियाँ शामिल हैं। इस विशाल प्राचीन पारिस्थितिकी तंत्र को जो 16,000 वर्ग मील (41,000 किमी2) में शामिल संरक्षित भूमि का भाग है, \"क्राउन ऑफ़ द कॉन्टिनेंट इकोसिस्टम\" के रूप में संदर्भित किया गया है।[1]\r\n\r\nग्लेशियर नेशनल पार्क में लगभग सभी मूल स्थानीय पेड़-पौधे और जीव-जन्तु प्रजातियाँ हैं। बड़े स्तनधारी जैसे भूरा भालू, मूस, और पहाड़ी बकरियों के साथ-साथ दुर्लभ या लुप्तप्राय प्रजातियाँ जैसे वूल्वरिन और कनाडाई लिनेक्स, भी इसी उद्यान में निवास करते हैं। यहाँ के पक्षियों की सैकड़ों प्रजातियों, मछलियों की एक दर्जन से अधिक प्रजातियों और कुछ सरीसृपों और उभयचर प्रजातियों को प्रलेखित किया गया है। उद्यान में प्रेरी से टुंड्रा तक कई पारिस्थितिकी-तंत्र हैं। उद्यान के दक्षिण-पश्चिम हिस्से में पश्चिमी रेडेकार्डर और हेमलॉक के जंगल हैं। उद्यान के जंगलों में आग लगना एक आम बात है। 1964 को छोड़ कर उद्यान में हर साल आग लगती है। 1936 में 64 बार आग लगी थी जो रिकॉर्ड में सबसे अधिक है।[2][3] 2003 में लगी छह आग ने लगभग 136,000 एकड़ (550 किमी2), उद्यान के 13% से अधिक हिस्से को जला डाला था।[4]', 12, 2, 1, 'Deleted', '2026-08-21 12:56:17', '2026-08-28 12:56:17', 1, 1, '2026-08-21 16:26:17', '2026-08-21 16:26:46'),
(3, 'ग्लेशियर नेशनल पार्क', 'ग्लेशियर नेशनल पार्क (अंग्रेज़ी: Glacier National Park; उच्चा.: ग्लेशियर नेशनल पार्क) अमेरिकी राष्ट्रीय उद्यान है, जो कनाडा-संयुक्त राज्य अमेरिका की सीमा के उत्तर-पश्चिमी मोंटाना राज्य में स्थित है और कनाडा की ओर अल्बर्टा और ब्रिटिश कोलम्बिया प्रांतों से सटा हुआ है। यह उद्यान दस लाख एकड़ (4,000 किमी2) से अधिक क्षेत्र में फैला हुआ है और इसमें दो पर्वत श्रृंखलाएँ (रॉकी पर्वत की उप-श्रेणियाँ), 130 से अधिक नामित झीलें, 1,000 से अधिक विभिन्न पौधों की प्रजातियाँ और वन्यजीवों की सैकड़ों प्रजातियाँ शामिल हैं। इस विशाल प्राचीन पारिस्थितिकी तंत्र को जो 16,000 वर्ग मील (41,000 किमी2) में शामिल संरक्षित भूमि का भाग है, \"क्राउन ऑफ़ द कॉन्टिनेंट इकोसिस्टम\" के रूप में संदर्भित किया गया है।[1]\r\n\r\nग्लेशियर नेशनल पार्क में लगभग सभी मूल स्थानीय पेड़-पौधे और जीव-जन्तु प्रजातियाँ हैं। बड़े स्तनधारी जैसे भूरा भालू, मूस, और पहाड़ी बकरियों के साथ-साथ दुर्लभ या लुप्तप्राय प्रजातियाँ जैसे वूल्वरिन और कनाडाई लिनेक्स, भी इसी उद्यान में निवास करते हैं। यहाँ के पक्षियों की सैकड़ों प्रजातियों, मछलियों की एक दर्जन से अधिक प्रजातियों और कुछ सरीसृपों और उभयचर प्रजातियों को प्रलेखित किया गया है। उद्यान में प्रेरी से टुंड्रा तक कई पारिस्थितिकी-तंत्र हैं। उद्यान के दक्षिण-पश्चिम हिस्से में पश्चिमी रेडेकार्डर और हेमलॉक के जंगल हैं। उद्यान के जंगलों में आग लगना एक आम बात है। 1964 को छोड़ कर उद्यान में हर साल आग लगती है। 1936 में 64 बार आग लगी थी जो रिकॉर्ड में सबसे अधिक है।[2][3] 2003 में लगी छह आग ने लगभग 136,000 एकड़ (550 किमी2), उद्यान के 13% से अधिक हिस्से को जला डाला था।[4]', 12, 2, 1, 'Published', '2026-08-21 12:57:12', '2026-08-28 12:57:12', 1, 0, '2026-08-21 16:27:10', '2026-08-21 16:27:21');

-- --------------------------------------------------------

--
-- Table structure for table `knowledge_attachments`
--

CREATE TABLE `knowledge_attachments` (
  `attachment_id` int(10) UNSIGNED NOT NULL,
  `knowledge_id` int(10) UNSIGNED NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(20) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(10) UNSIGNED NOT NULL,
  `uploaded_by` int(10) UNSIGNED NOT NULL,
  `uploaded_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `knowledge_attachments`
--

INSERT INTO `knowledge_attachments` (`attachment_id`, `knowledge_id`, `file_name`, `stored_name`, `file_path`, `file_type`, `mime_type`, `file_size`, `uploaded_by`, `uploaded_date`) VALUES
(1, 1, 'Test report Format.xlsx', '131925e012e3abd6ec06d4be466da6bb.xlsx', 'assets/uploads/131925e012e3abd6ec06d4be466da6bb.xlsx', 'xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 11840, 2, '2026-08-21 16:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `location_id` int(10) UNSIGNED NOT NULL,
  `location_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `location_name`, `is_active`, `created_at`) VALUES
(1, 'NML HQ', 1, '2026-08-21 15:30:03');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(10) UNSIGNED NOT NULL,
  `knowledge_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `role_name` varchar(30) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `description`) VALUES
(1, 'Super User', 'Full system control, no restrictions'),
(2, 'Admin', 'Manages employees and knowledge, permissions set by Super User'),
(3, 'Employee', 'Submits and manages own knowledge within edit window');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `session_id` varchar(128) NOT NULL,
  `employee_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `payload` mediumtext DEFAULT NULL,
  `last_activity` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(500) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`setting_key`, `setting_value`, `description`, `updated_at`) VALUES
('allow_zip_uploads', '1', 'Whether ZIP attachments are permitted (0/1)', '2026-08-21 15:30:02'),
('allowed_file_types', 'pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,txt,zip', 'Comma-separated list of allowed file extensions', '2026-08-21 15:30:02'),
('edit_window_days', '7', 'Number of days an employee may edit/delete their own knowledge', '2026-08-21 15:30:02'),
('max_upload_size_mb', '25', 'Maximum size per uploaded file in MB', '2026-08-21 15:30:02'),
('title_max_length', '150', 'Maximum characters allowed in knowledge title', '2026-08-21 15:30:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_log_employee` (`employee_id`),
  ADD KEY `idx_log_module_action` (`module`,`action`),
  ADD KEY `idx_log_created` (`created_at`);

--
-- Indexes for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD UNIQUE KEY `uq_emp_module` (`employee_id`,`module_key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`),
  ADD UNIQUE KEY `department_name` (`department_name`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `employee_number` (`employee_number`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `fk_emp_grade` (`grade_id`),
  ADD KEY `fk_emp_location` (`location_id`),
  ADD KEY `fk_emp_created_by` (`created_by`),
  ADD KEY `idx_emp_role` (`role_id`),
  ADD KEY `idx_emp_status` (`status`),
  ADD KEY `idx_emp_department` (`department_id`);

--
-- Indexes for table `employee_grades`
--
ALTER TABLE `employee_grades`
  ADD PRIMARY KEY (`grade_id`),
  ADD UNIQUE KEY `grade_code` (`grade_code`);

--
-- Indexes for table `knowledge`
--
ALTER TABLE `knowledge`
  ADD PRIMARY KEY (`knowledge_id`),
  ADD KEY `fk_know_department` (`department_id`),
  ADD KEY `idx_know_status` (`status`),
  ADD KEY `idx_know_employee` (`employee_id`),
  ADD KEY `idx_know_category` (`category_id`);
ALTER TABLE `knowledge` ADD FULLTEXT KEY `ft_know_search` (`title`,`description`);

--
-- Indexes for table `knowledge_attachments`
--
ALTER TABLE `knowledge_attachments`
  ADD PRIMARY KEY (`attachment_id`),
  ADD KEY `fk_att_uploader` (`uploaded_by`),
  ADD KEY `idx_att_knowledge` (`knowledge_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`),
  ADD UNIQUE KEY `location_name` (`location_name`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `fk_notif_knowledge` (`knowledge_id`),
  ADD KEY `idx_notif_employee_read` (`employee_id`,`is_read`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `fk_sess_employee` (`employee_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  MODIFY `permission_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee_grades`
--
ALTER TABLE `employee_grades`
  MODIFY `grade_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `knowledge`
--
ALTER TABLE `knowledge`
  MODIFY `knowledge_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `knowledge_attachments`
--
ALTER TABLE `knowledge_attachments`
  MODIFY `attachment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_log_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE SET NULL;

--
-- Constraints for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  ADD CONSTRAINT `fk_perm_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `fk_emp_created_by` FOREIGN KEY (`created_by`) REFERENCES `employees` (`employee_id`),
  ADD CONSTRAINT `fk_emp_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`),
  ADD CONSTRAINT `fk_emp_grade` FOREIGN KEY (`grade_id`) REFERENCES `employee_grades` (`grade_id`),
  ADD CONSTRAINT `fk_emp_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`),
  ADD CONSTRAINT `fk_emp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`);

--
-- Constraints for table `knowledge`
--
ALTER TABLE `knowledge`
  ADD CONSTRAINT `fk_know_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `fk_know_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`),
  ADD CONSTRAINT `fk_know_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`);

--
-- Constraints for table `knowledge_attachments`
--
ALTER TABLE `knowledge_attachments`
  ADD CONSTRAINT `fk_att_knowledge` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge` (`knowledge_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_att_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `employees` (`employee_id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notif_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_notif_knowledge` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge` (`knowledge_id`) ON DELETE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `fk_sess_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
