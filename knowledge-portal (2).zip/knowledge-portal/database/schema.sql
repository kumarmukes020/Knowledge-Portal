-- ============================================================
-- Online Knowledge Sharing Portal — Database Schema
-- Engine: MySQL 8+ / MariaDB 10.4+
-- Charset: utf8mb4 (full emoji/unicode support)
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS knowledge_portal
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE knowledge_portal;

-- ============================================================
-- 1. MASTER DATA TABLES
-- ============================================================

CREATE TABLE roles (
    role_id     TINYINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    role_name   VARCHAR(30) NOT NULL UNIQUE,   -- 'Super User', 'Admin', 'Employee'
    description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

INSERT INTO roles (role_id, role_name, description) VALUES
    (1, 'Super User', 'Full system control, no restrictions'),
    (2, 'Admin',       'Manages employees and knowledge, permissions set by Super User'),
    (3, 'Employee',    'Submits and manages own knowledge within edit window');

CREATE TABLE departments (
    department_id   INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    department_name VARCHAR(100) NOT NULL UNIQUE,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE locations (
    location_id   INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    location_name VARCHAR(100) NOT NULL UNIQUE,   -- e.g. NML HQ, PBCMP, CBCMP
    is_active     TINYINT(1) NOT NULL DEFAULT 1,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
    category_id   INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL UNIQUE,   -- IT, HR, Finance, Legal, Mining, Safety...
    is_active     TINYINT(1) NOT NULL DEFAULT 1,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE employee_grades (
    grade_id   TINYINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    grade_code VARCHAR(10) NOT NULL UNIQUE   -- E1..E9
) ENGINE=InnoDB;

INSERT INTO employee_grades (grade_code) VALUES
    ('E1'),('E2'),('E3'),('E4'),('E5'),('E6'),('E7'),('E8'),('E9');

-- ============================================================
-- 2. EMPLOYEE / USER TABLE
-- ============================================================

CREATE TABLE employees (
    employee_id     INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    employee_number VARCHAR(20) NOT NULL UNIQUE,
    employee_name   VARCHAR(150) NOT NULL,
    grade_id        TINYINT UNSIGNED DEFAULT NULL,
    location_id     INT UNSIGNED DEFAULT NULL,
    department_id   INT UNSIGNED DEFAULT NULL,
    mobile_number   VARCHAR(20) DEFAULT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    username        VARCHAR(50) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,          -- password_hash() / Argon2id
    must_change_password TINYINT(1) NOT NULL DEFAULT 1,  -- forced on next login until changed
    role_id         TINYINT UNSIGNED NOT NULL,
    status          ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    failed_login_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until    DATETIME DEFAULT NULL,
    last_login_at   DATETIME DEFAULT NULL,
    created_by      INT UNSIGNED DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_emp_grade      FOREIGN KEY (grade_id)      REFERENCES employee_grades(grade_id),
    CONSTRAINT fk_emp_location   FOREIGN KEY (location_id)   REFERENCES locations(location_id),
    CONSTRAINT fk_emp_department FOREIGN KEY (department_id) REFERENCES departments(department_id),
    CONSTRAINT fk_emp_role       FOREIGN KEY (role_id)       REFERENCES roles(role_id),
    CONSTRAINT fk_emp_created_by FOREIGN KEY (created_by)    REFERENCES employees(employee_id),
    INDEX idx_emp_role (role_id),
    INDEX idx_emp_status (status),
    INDEX idx_emp_department (department_id)
) ENGINE=InnoDB;

-- Optional: role-based module permissions for Admin (Super User sets these)
CREATE TABLE admin_permissions (
    permission_id   INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    employee_id     INT UNSIGNED NOT NULL,
    module_key      VARCHAR(50) NOT NULL,   -- e.g. 'manage_categories', 'manage_departments'
    is_allowed      TINYINT(1) NOT NULL DEFAULT 0,
    UNIQUE KEY uq_emp_module (employee_id, module_key),
    CONSTRAINT fk_perm_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 3. KNOWLEDGE TABLES
-- ============================================================

CREATE TABLE knowledge (
    knowledge_id    INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    title           VARCHAR(255) NOT NULL,
    description     MEDIUMTEXT NOT NULL,
    category_id     INT UNSIGNED NOT NULL,
    employee_id     INT UNSIGNED NOT NULL,          -- author
    department_id   INT UNSIGNED DEFAULT NULL,
    status          ENUM('Draft','Submitted','Published','Archived','Deleted') NOT NULL DEFAULT 'Draft',
    submitted_date  DATETIME DEFAULT NULL,
    editable_until  DATETIME DEFAULT NULL,           -- submitted_date + 7 days, computed at submit time
    view_count      INT UNSIGNED NOT NULL DEFAULT 0,
    is_deleted      TINYINT(1) NOT NULL DEFAULT 0,   -- soft delete
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_know_category   FOREIGN KEY (category_id)   REFERENCES categories(category_id),
    CONSTRAINT fk_know_employee   FOREIGN KEY (employee_id)   REFERENCES employees(employee_id),
    CONSTRAINT fk_know_department FOREIGN KEY (department_id) REFERENCES departments(department_id),
    INDEX idx_know_status (status),
    INDEX idx_know_employee (employee_id),
    INDEX idx_know_category (category_id),
    FULLTEXT INDEX ft_know_search (title, description)
) ENGINE=InnoDB;

CREATE TABLE knowledge_attachments (
    attachment_id   INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    knowledge_id    INT UNSIGNED NOT NULL,
    file_name       VARCHAR(255) NOT NULL,   -- original name shown to user
    stored_name     VARCHAR(255) NOT NULL,   -- unique name on disk, prevents overwrite
    file_path       VARCHAR(500) NOT NULL,
    file_type       VARCHAR(20)  NOT NULL,   -- extension, e.g. pdf, docx
    mime_type       VARCHAR(100) NOT NULL,
    file_size        INT UNSIGNED NOT NULL,  -- bytes
    uploaded_by     INT UNSIGNED NOT NULL,
    uploaded_date   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_att_knowledge FOREIGN KEY (knowledge_id) REFERENCES knowledge(knowledge_id) ON DELETE CASCADE,
    CONSTRAINT fk_att_uploader  FOREIGN KEY (uploaded_by)  REFERENCES employees(employee_id),
    INDEX idx_att_knowledge (knowledge_id)
) ENGINE=InnoDB;

-- ============================================================
-- 4. NOTIFICATIONS
-- ============================================================

CREATE TABLE notifications (
    notification_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    employee_id      INT UNSIGNED NOT NULL,         -- recipient
    knowledge_id     INT UNSIGNED DEFAULT NULL,
    type             VARCHAR(50) NOT NULL,          -- submitted, updated, expiring_soon, expired, new_knowledge
    message          VARCHAR(500) NOT NULL,
    is_read          TINYINT(1) NOT NULL DEFAULT 0,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_notif_employee  FOREIGN KEY (employee_id)  REFERENCES employees(employee_id) ON DELETE CASCADE,
    CONSTRAINT fk_notif_knowledge FOREIGN KEY (knowledge_id) REFERENCES knowledge(knowledge_id) ON DELETE CASCADE,
    INDEX idx_notif_employee_read (employee_id, is_read)
) ENGINE=InnoDB;

-- ============================================================
-- 5. ACTIVITY LOG (AUDIT TRAIL)
-- ============================================================

CREATE TABLE activity_logs (
    log_id       BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    employee_id  INT UNSIGNED DEFAULT NULL,     -- null allowed for failed pre-auth attempts
    action       VARCHAR(50) NOT NULL,          -- LOGIN, LOGOUT, CREATE, UPDATE, DELETE, UPLOAD...
    module       VARCHAR(50) NOT NULL,          -- Knowledge, Employee, Auth, Attachment...
    record_id    INT UNSIGNED DEFAULT NULL,
    description  VARCHAR(500) DEFAULT NULL,
    ip_address   VARCHAR(45) DEFAULT NULL,
    user_agent   VARCHAR(255) DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_log_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE SET NULL,
    INDEX idx_log_employee (employee_id),
    INDEX idx_log_module_action (module, action),
    INDEX idx_log_created (created_at)
) ENGINE=InnoDB;

-- ============================================================
-- 6. SESSION TABLE (optional DB-backed sessions, more secure than default file sessions)
-- ============================================================

CREATE TABLE sessions (
    session_id   VARCHAR(128) PRIMARY KEY,
    employee_id  INT UNSIGNED NOT NULL,
    ip_address   VARCHAR(45) DEFAULT NULL,
    user_agent   VARCHAR(255) DEFAULT NULL,
    payload      MEDIUMTEXT,
    last_activity DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_sess_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 7. SYSTEM SETTINGS (configurable limits: title length, allowed file types, etc.)
-- ============================================================

CREATE TABLE system_settings (
    setting_key   VARCHAR(100) PRIMARY KEY,
    setting_value VARCHAR(500) NOT NULL,
    description   VARCHAR(255) DEFAULT NULL,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
    ('title_max_length', '150', 'Maximum characters allowed in knowledge title'),
    ('edit_window_days', '7', 'Number of days an employee may edit/delete their own knowledge'),
    ('max_upload_size_mb', '25', 'Maximum size per uploaded file in MB'),
    ('allowed_file_types', 'pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,txt,zip', 'Comma-separated list of allowed file extensions'),
    ('allow_zip_uploads', '1', 'Whether ZIP attachments are permitted (0/1)');

-- ============================================================
-- 8. SEED: Default Super User (CHANGE PASSWORD IMMEDIATELY AFTER FIRST LOGIN)
-- Password below is a placeholder hash for 'ChangeMe@123' — regenerate in app, never ship real hashes in SQL.
-- ============================================================

INSERT INTO departments (department_name) VALUES ('Information Technology'), ('Administration');
INSERT INTO locations (location_name) VALUES ('NML HQ');
INSERT INTO categories (category_name) VALUES
    ('IT'),('HR'),('Finance'),('Legal'),('Contracts'),('Mining'),
    ('Safety'),('Environment'),('Projects'),('R&R'),('Procurement'),('General');

-- NOTE: Replace password_hash with output of PHP password_hash('YourRealPassword', PASSWORD_ARGON2ID)
INSERT INTO employees
    (employee_number, employee_name, grade_id, location_id, department_id, mobile_number, email, username, password_hash, role_id, status)
VALUES
    ('SU0001', 'System Administrator', NULL, 1, 1, NULL, 'admin@yourorg.com', 'superuser',
     '$2y$12$REPLACE_WITH_REAL_HASH_GENERATED_BY_PHP', 1, 'Active');

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- MIGRATION — run this ONE line if you already created the database
-- before this file added the must_change_password column. Safe to
-- run once; re-running is harmless if the column already exists.
-- ============================================================
-- ALTER TABLE employees ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 1 AFTER password_hash;

